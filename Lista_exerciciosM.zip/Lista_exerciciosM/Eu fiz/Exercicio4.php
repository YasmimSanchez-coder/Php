<!-- 4. Matriz 2x2 Estática
	Crie uma matriz 2x2 e exiba seus valores em uma tabela HTML, 
	usando o comando for.-->


<!doctype html>
<html>
	<head>
		<title>Exercìcio 4</title>
		<meta charset="UTF-8">
		
		<style>
			.space{line-height: 16px;}
		</style>
	</head>
	
	<body>
		<h2>Tabela das Notas</h2>
		<table>
			<div class="space"> 
				<tr>
				
					<tr>Nomes</tr>
					<tr>Notas</tr>
				</tr>
			</div>
			<br><br>
			<tr>
				<tr>
					<?php
					 
						$notas = array (array("Melissa", 10.0),
										array("Clara", 5.5));
						
						for($lin=0; $lin < 2; $lin++)
						{
							for($col=0; $col < 2; $col++)
							{
							echo "{$notas[$lin][$col]}<br>";
							}
						}
					?>
				</tr>
			</tr>
		</table>
	</body>
</html>