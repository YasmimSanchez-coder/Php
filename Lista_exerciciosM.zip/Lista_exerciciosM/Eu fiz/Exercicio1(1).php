<?php
/*1. Exibir um Vetor Simples
Crie um vetor com 5 nomes e exiba-os em uma lista <ul> no HTML.*/

//1- modo
$nomes = array("Yasmim", "Rayssa", "Marina", "Tamires", "Kaike");

echo "<ul>";

foreach($nomes as $nome)
{
	echo"<li>$nome</li>";
}

echo "</ul>";
