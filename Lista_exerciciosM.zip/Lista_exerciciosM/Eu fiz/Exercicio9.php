<!--9. Criar um Vetor de Cores e Exibi-las em HTML
Crie um vetor de cores e use-o para exibir quadrados coloridos 
(<div style="width:50px; height:50px; background-color:cor;"></div>).-->

<?php
//Cores
$cores = ['yellow', 'green', 'pink', 'blue', 'purple', 'orange'];

//HTML
echo '<!DOCTYPE html>';
echo '<html lang="pt-BR">';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<title></title>';
echo '</head>';
echo '<body>';

//Div
foreach ($cores as $cor) {
    echo '<div style="width:50px; height:50px; background-color:' . $cor . '; display:inline-block; margin:5px;"></div>';
}

//HTML
echo '</body>';
echo '</html>';
?>