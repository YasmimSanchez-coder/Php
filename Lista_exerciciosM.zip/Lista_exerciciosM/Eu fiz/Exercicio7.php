<!--7. Copiar os Elementos de um Vetor para Outro
Crie um vetor com 4 números e copie cada valor 
manualmente para um segundo vetor.-->

<?php
   $Elementos = array(3, 6, 2, 7); //Elementos com 4 números