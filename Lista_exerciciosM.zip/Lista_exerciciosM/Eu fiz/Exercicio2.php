<?php
/*2. Somar Elementos de um Vetor
Crie um vetor com 5 números inteiros e some manualmente os valores 
acessando cada índice diretamente.*/

$numeros = array(1, 2, 3, 4, 5); //vetores

	//usando o for
	for($x=0; $x < count($numeros); $x++)
	{
		echo "$numeros[$x]<br>";
	}
	
	echo "<br><br>";
	
	$numeros[] = $x+1; //número + 1
	
	foreach($numeros as $dado)
	{
		echo "$dado<br>";
	}
?>