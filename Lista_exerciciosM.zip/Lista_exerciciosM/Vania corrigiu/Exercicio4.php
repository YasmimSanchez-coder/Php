<!--4. Matriz 2x2 Estática
Crie uma matriz 2x2 e exiba seus valores em uma tabela HTML, usando comando for.-->

<!doctype html>
<html>
 <head>
     <title> Exercicio 4 </title>
	 <meta charset="UTF-8">
 </head>
 <body>
    <table border="1">
  <?php
   $mat = array(array (1,2),
                array (3,4)
				);
	foreach($mat as $vet)
	{
		echo "<tr>";
		foreach($vet as $dado)
		{
		    echo  "<td> {$dado}
			</td>";
		}
		echo"</tr>";
	}
  ?>
	</table>
</body>
</html>