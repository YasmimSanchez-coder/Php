<?php
	class Cliente extends Pessoa //extends = classe pai
	{
		public function __construct(private string $cpf = "", $nome, 
		$ddd, $numero)
		{
			parent :: __construct($nome, $ddd, $numero); 
			//referencia a pessoa (MESMA ORDEM)
		}
		
		public function getCpf()
		{
		return $this->cpf;
		}
		
		public function setCpf()
		{
		$this-> cpf = $cpf;
		}
	}
?>