<?php

    class Orcamento
    {
		public function __construct(private  string $data_orcamento = "", private float $preco = 0.00, private string $data_validade = "", private $aparelho = null, private $tecnico = null){} 
		//caso n tipar = null

        public function getData_orcamento()
		{ 
			return $this->data_orcamento;	
		}

        public function getPreco()
		{ 
			return $this->preco;
		}

        public function getData_validade()
		{ 
			return $this->data_validade;
		}

        
        public function setData_orcamento($data)
		{
			$this->data_orcamento = $data;
		}

        public function setPreco($preco)
		{
			$this->preco = $preco;
		}
		
		public function setData_validade($data)
		{
			$this->data_validade = $data;
		}
		
        public function getAparelho()
		{ 
			return $this->aparelho;
		}

        public function setAparelho($aparelho)
		{
			$this->aparelho = $aparelho;
		}
		
		public function getTecnico()
		{ 
			return $this->tecnico;
		}

        public function setTecnico($Tecnico)
		{
			$this->tecnico = $tecnico;
		}

    }
?>