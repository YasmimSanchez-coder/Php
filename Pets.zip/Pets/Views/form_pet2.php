<?php
require_once "../Models/Pet.class.php";
$msg = array("", "", "", "");
$erro = false;
$nome = $idade = $cor = $raca = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"] ?? "";
    $idade = $_POST["idade"] ?? "";
    $cor = $_POST["cor"] ?? "";
    $raca = $_POST["raca"] ?? "";

    if (empty($nome)) {
        $msg[0] = "Preencha o nome por favor";
        $erro = true;
    }
    if (empty($idade)) {
        $msg[1] = "Preencha a idade por favor";
        $erro = true;
    }
    if (empty($cor)) {
        $msg[2] = "Preencha a cor por favor";
        $erro = true;
    }
    if ($raca == "0") {
        $msg[3] = "Escolha uma raça";
        $erro = true;
    }

    if (!$erro) {
        $pet = new Pet($nome, (int)$idade, $cor, $raca);
        echo "<div class='resultado'>";
        echo "Nome: {$pet->getNome()}<br>";
        echo "Idade: {$pet->getIdade()}<br>";
        echo "Cor: {$pet->getCor()}<br>";
        echo "Raça: {$pet->getRaca()}<br>";
        echo "</div>";
    }
}
?>

<!doctype html>
<html>
<head>
    <title>Pets</title>
    <meta charset="UTF-8">
</head>
<body>
    <h1>Pet</h1>
    <form action="#" method="post">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo htmlspecialchars($nome); ?>">
        <div class='erro'><?php echo $msg[0]; ?></div>

        <label>Idade:</label>
        <input type="text" name="idade" value="<?php echo htmlspecialchars($idade); ?>">
        <div class='erro'><?php echo $msg[1]; ?></div>

        <label>Cor:</label>
        <input type="text" name="cor" value="<?php echo htmlspecialchars($cor); ?>">
        <div class='erro'><?php echo $msg[2]; ?></div>

        <label>Raça:</label>
            <select name="raca">
       <option value="0"> Escolha a raça</option>
       <option>Pitbull</option>
	   <option>Lhasa</option>
	   <option>Yorkshare</option>
	   <option>SRD</option> 
	 </select>
        <div class='erro'><?php echo $msg[3]; ?></div>

        <button type="submit">Cadastrar</button>
    </form>
</body>
</html>
