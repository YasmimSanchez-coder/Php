<?php
/*
   $pessoa = array("Maria", 25, 1.69, 47.8, true);
   
   //definindo um array com indice por numero
   usando for
   for ($x=0; $x < 5; $x++)
   {
   echo "$pessoa[$x] <br>";
   }
   
   for($x = 0; $x < count($pessoa); $x++)
   {   
    echo "$pessoa[$x] <br>";
   }
   
   echo "<br><br>";
   
      //usando foreach forma reduzida
   foreach($pessoa as $dado)
   {
	 echo "$dado<br>";   
   }
   
   echo "<br><br>"; //espaço pra não ficar tudo grudado
   
      //usando foreach forma completa
   foreach($pessoa as $indice=>$dado)
   {
   echo "$indice:$dado<br>";
   }
   
     //colocando mais um item na matriz
   $pessoa[] = "Castanho";
   
  
  //definindo um array com indice nomeado
  $pessoal = array("Nome"=>"Maria", "Idade"=>25,
  "Altura"=>1.69, "Peso"=>47.8, "Casado"=>false);
  
  foreach($pessoal as $indice=>$dado)
  {
	  echo "$indice - $dado<br>";
  }
  
    */
   //matriz de duas dimensoes
 $notas = array(
           array("Carlos", "5.5", "6.0", "7.0"), //podemos colocar os vetores 
		   array("Pedro", "10.0", "10.0", "10.0"),
		   array("Fatima", "2.5", "10.0", "10.0"));
	/*	  
   //usando for para mostrar dados da matriz
   for($lin=0; $lin < 3; $lin++)
   {
	   for($col=0; $col < 4; $col++)
	   {
	   echo"{$notas[$lin] [$col]}<br>";
	   }
   }
   echo "<br><br>";
   
   //usando foreach
   foreach($notas as $vetor)
   {
	   foreach($vetor as $dados)
	   {
		   echo"$dados<br>";
	   }
   }
 
    */
   echo "<pre>"; //recurso de programador (é meio feio como mostra)
   print_r($notas); //ou var_dump (mostra feio melhor o print_r) e não esquecer de deixar array amostra
   echo "</pre>"
?>