<?php
  final class contaCorrente extends Conta //não quer q ela tenha "filhas" (final class)
  {
	  public function __construct(private float $limite = 0.00,
	  string $agencia, string $conta, float $saldo)
	  {
		  parent::__construct ($agencia, $conta, $saldo);
	  }
	  
	  //metodos
	  public function sacar($valor)
	  {
	    if($this->saldo + $this->limite >= $valor)
		{
          parent::sacar	($valor);
		}
       else
	   {
          echo "Saldo Insuficiente<br>";
	   }		  
	  }
	  
	  public function getLimite()
	  {
		  return $this->Limite;
	  }
	  
	  public function setLimite ($limite)
	  {
		  $this->$limite = $limite;
	  }
  }
?>