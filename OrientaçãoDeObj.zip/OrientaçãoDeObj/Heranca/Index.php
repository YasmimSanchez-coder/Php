<?php
   require_once "Conta.php";
   require_once "Conta_Poupança.php";
   require_once "Conta_Corrente.php";
   
   $poupanca = new contaPoupança(01,"123-4","3456-7",1000.00); 
   //Ordem: Aniversario, Agência, Conta e Saldo)
   //Sempre que usar o Ç em 1 arquivo usar em todos
   
   /*echo "<pre>";
   var_dump($poupanca);
   echo "</pre>";*/
   
   $poupanca->sacar(500);
   echo "Saldo: {$poupanca->getSaldo()}<br>";
   
   $corrente= new contaCorrente(3000, "235-9", "7654-2", 5000); //ele pode sacar ATÉ 8000
   
   $corrente->sacar(1000000000);
   echo "Saldo: {$corrente->getSaldo()}<br>";
?>
