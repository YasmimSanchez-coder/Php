<?php
  class Conta
  {
	  public function __construct(protected string $agencia = "", //o protected só as "classe filhas" pode acessar a "classe pai"
	                              protected string $conta = "", 
								  protected float $saldo = 0.00) {}
//Quando for private sempre tera um get e um set para pegar e colocar um valor

//mètodos
      public function sacar($valor)
	  {
		  $this->saldo -=$valor;
	  }
	  public function getAgencia()
	  {
		  return $this->agencia;
	  }
	  
	  public function setAgencia($agencia)
	  {
		  $this->$limite = $agencia;
	  }
	  
	  public function getConta()
	  {
		  return $this->conta;
	  }
	  
	  public function setConta($conta)
	  {
		  $this->$limite = $conta;
	  }
	  
	  	  public function getSaldo()
	  {
		  return $this->saldo;
	  }
	  
	  public function setSaldo($saldo)
	  {
		  $this->$limite = $saldo;
	  }
  }
?>