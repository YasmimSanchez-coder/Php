<?php
	require_once "Produto.class.php";
	require_once "Fornecedor.class.php";
	
	$fornecedor1 = new Fornecedor ("111.111.111/0001-11", "Faber Castell",
	new Produto()); 
	
	$produto1 = new Produto("Làpis Preto", "Lapis Preto numero 2", 
	3.5, array($fornecedor1));
	
	$fornecedor2 = new Fornecedor ("222.222.222/0002-22", "pilot", new Produto()); 
	                                                              //Sem produto colocar como acima
	$produto1->setFornecedor($fornecedor2);

	/*echo "<pre>";
	var_dump($produto1);
	echo"</pre>";*/
	echo "Nome: {$produto1->getNome()}<br>";//tira todos os dados que estão dentro
	echo "Descrição: {$produto1->getDescricao()}<br>";
	echo "Preço: " . number_format ($produto1->getPreco(),2,",",".") . "<br>";
	echo "Fornecedores<br>";
	foreach ($produto1->getFornecedor() as $dado)
	{
		echo"CNPJ: {$dado->getCnpj()} <br>"; //pegar dado
		echo"Razão Social: {$dado->getRazaoSocial()} <br>";
	}

	$produto2 = new Produto("Caneta Esteriogràfica", 
	"Caneta Esteriogràfica azul", "4.50");
	
	$fornecedor3 = new Fornecedor(
	"333.333.333/0001-33", "Bic", $produto2);
	
	echo "CNPJ: {$fornecedor3->getCNPJ()}<br>";
	echo "Razão Social: {$fornecedor3->getRazaoSocial()}<br>";
	echo "Produto<br>";
	echo "Nome:{$fornecedor3->getProduto()->getNome()}<br>"; 
	//até o produto é objeto o get nome da o nome
	echo "Descrição:{$fornecedor3->getProduto()->getDescricao()}<br>"; 
	echo "Preço:{$fornecedor3->getProduto()->getPreco()}<br>"; 
?>