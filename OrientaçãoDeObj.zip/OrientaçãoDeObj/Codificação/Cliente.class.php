<?php
	class Cliente
	{
		//Na maioria das vezes, construtures são públicos, Sempre usar 2 _, um unico construct já basta, priv apenas nos atributos
		public function __construct (private string $nome = "", 
		private string $cpf = "",  //quando com aspas podemos fazer como o cliente 3
		private string $celular = ""){}
		
		public function getNome() //obter o nome
		{
			return $this->nome;
		}
		public function setNome($nome) //colocar valor o atributo
		{
			$this->nome = $nome;
		}
		
		public function inserir()
		{
		}
	} //fim da classes
	
	$cliente1 = new Cliente("Paulo da Silva", "111.111.111-11", "(14)996936628");
	//$cliente1-> nome= "Paulo da silva texeira"; a ordem é importante quando fazemos a passem do valor, caso privado dara erro esse cod por ser priv
	
	echo "{$cliente1->getNome()}<br>";
	
	$cliente1->setNome ("Paulo Rocha");
	echo $cliente1->getNome("Paulo Rocha");
	
	echo "<pre>";
	var_dump($cliente1);
	echo "</pre>";
	
	$cliente2 = new Cliente("Maria da Silva", "222.222.222-22", "(14)997715789");
	echo "<pre>";
	var_dump($cliente2);
	echo "</pre>";
	
	$cliente3 = new Cliente();
	echo "<pre>";
	var_dump($cliente3);
	echo "</pre>";
	
	$cliente4 = new Cliente(celular:"(14)999999999"); //se for por referencia ("", "", "o telefone"), falar qual é o atributo
	echo "<pre>";
	var_dump($cliente4);
	echo "</pre>";
	
?>