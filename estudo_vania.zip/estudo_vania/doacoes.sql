DROP DATABASE doacoes;
CREATE DATABASE doacoes;
USE doacoes;

CREATE TABLE doadores (
  iddoador INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  contato VARCHAR(100) NULL,
  PRIMARY KEY(iddoador)
);

CREATE TABLE doacoes (
  iddoacao INT UNSIGNED NOT NULL AUTO_INCREMENT,
  iddoador INT UNSIGNED NOT NULL,
  data_doacao DATE NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  tipo_doacao VARCHAR(50) NOT NULL,
  PRIMARY KEY(iddoacao),
  FOREIGN KEY(iddoador)
    REFERENCES doadores(iddoador)
);