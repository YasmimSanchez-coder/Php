<?php
    if($_GET) {
        $controle = $_GET["controle"];
        $metodo = $_GET["metodo"];
    } else {
        $controle = "inicio";
        $metodo = "inicio";
    }
    $controle = $controle . "Controller";
    require_once("controllers/{$controle}.class.php");
    $obj = new $controle();
    $obj->$metodo();
?>