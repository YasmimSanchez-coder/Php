<?php
    class Doador {
        public function __construct(
            private Int $iddoador = 0,
            private String $nome = "",
            private String $contato = ""
        ){}
        public get($atributo){
            return $this->$atributo;
        }
        public set($atributo, $valor){
            $this->$atributo = $valor;
        }
    }
?>