<?php
    class Doacao {
        public function __construct(
            private Int $iddoacao = 0,
            private Int $iddoador = 0,
            private String $data_doacao = "",
            private Float $valor = 0.00,
            private String $tipo_doacao = ""
        ){}
        public get($atributo){
            return $this->$atributo;
        }
        public set($atributo, $valor){
            $this->$atributo = $valor;
        }
    }
?>