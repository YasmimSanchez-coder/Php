<?php
    $pagina = "Listar Doações";
    require_once("header.php");
    
    function tabelaHTML($tabela){
        foreach($tabela as $linha){
            echo "<tr>";
            foreach($linha as $indice => $info){
                echo "<td>{$info}</td>";
            }
            echo "</tr>";
        }
    }
?>  
    <h1>Listar Doações</h1>
    <h2>Doações</h2>
    <p>Depois colocar um função onde ele passa o mouse por cima
        ou clica em cima do id do Doador e mostra as informações do
        Doador em um janelinha, ai não precisa procurar na listinha enorme
    </p>
    <table>
        <tr>
            <th>Doador</th>
            <th>Valor</th>
            <th>Data</th>
            <th>Tipo</th>
        </tr>
        <?php
            tabelaHTML($doacoes);
        ?>
    </table>
    <h2>Doadores</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Contato</th>
        </tr>
        <?php
            tabelaHTML($doadores);
        ?>
    </table>
    <a href="index.php?controle=doacao&metodo=registrar">
        <button>Nova Doacao</button>
    </a>
</main>
</body>
</html>