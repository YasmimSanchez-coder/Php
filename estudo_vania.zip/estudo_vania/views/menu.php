<?php
	$pagina = "Menu";
	require_once("header.php");
?>
</body>
</html>