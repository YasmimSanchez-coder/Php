<?php
	class Chef
	{
		public function __construct(private int $id_chef = 0, private string $nome = "", private string $especialidade = ""){}
		
		public function getId_chef()
		{
			return $this->id_chef;
		}
		public function getNome()
		{
			return $this->nome;
		}

        public function getEspecialidade()
		{
			return $this->especialidade;
		}
	}//fim da classe chef
?>