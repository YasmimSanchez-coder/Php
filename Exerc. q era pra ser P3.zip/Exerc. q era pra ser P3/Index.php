<?php
    if($_GET) //saber se é verdadeiro ou falso e toda vez q o usuario clica em um link
    {
        $controle= $_GET["controle"]; //qual o controle
        $metodo= $_GET["metodo"]; //qual o método
        require_once "Controllers/{$controle}.class.php"; //precisa fazr antes
        $Obj = new $controle(); //generico
        $Obj->$metodo();
    }
    else //toda vez q entra no projeto
    {
        require_once "Controllers/InicioController.class.php" ; //criar um objeto da classe InicioController
        $Obj = new InicioController(); //instanciar o objeto
        $Obj->inicio();
    }
    //Index cooringa
?>