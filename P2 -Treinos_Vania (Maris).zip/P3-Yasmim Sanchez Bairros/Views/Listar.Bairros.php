<?php
require_once "Menu.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Bairros</title>
        <meta charset="UTF-8">
    </head>
    <body>
	<table border="1">
			<tr>
				<th>Nome</th>
				<th>Id do bairro</th>
				<th>Id da cidade</th>
				<th>Região</th>
				<th>comentarios</th>
	</tr>
	<?php
				foreach($retorno as $dados)
				{	
					echo "<tr>
					      <td>{$dados->nome}</td>
						  <td>{$dados->idbairro}</td>
						  <td>{$dados->idcidade}</td>
						  <td>{$dados->regiao}</td>
                          <td>{$dados->comentario}</td>
						  <td><a href='/Edit.bairro.php/alterar/{$dados->idbairro}' class='btn btn-warning'>Alterar</a>
						  <td><a href='/Edit.bairro.php/excluir/{$dados->idbairro}' class='btn btn-warning'>excuirr</a>
		  				</tr>";	  
				}
		?>
		</table>
		</body>
		</html>