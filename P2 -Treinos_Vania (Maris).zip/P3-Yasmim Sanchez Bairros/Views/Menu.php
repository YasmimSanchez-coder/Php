<!DOCTYPE html>
<html>
    <head>
        <title>Bairros</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <a href="Index.php?controle=BairroController&metodo=listar">Listar Bairro</a>
    </body>
</html>
