<?php
	require_once "menu.php";
?>
	<div class="content">
	<div class="container">
	<br>
		<h1>Bairro</h1>
	<br>
		<form action="/Bairro/alterar" method="post">
		
			<input type="hidden" name="idbairro" value="<?php echo $retorno[0]->idbairro; ?>">
			
			<label for="Nome">Nome:</label>
			<input type="text" name="Nome" id="Nome" value="<?php echo $retorno[0]->nome;?>">
			<div style="color:red;font-size:12px;"><?php echo $erro;?></div>
			<br><br>

			<label for="comentario">Comentario:</label>
			<input type="text" name="comentario" id="comentario" value="<?php echo $retorno[0]->comentario;?>">
			<div style="color:red;font-size:12px;"><?php echo $erro;?></div>
			<br><br>

			<input type="submit" value="Alterar">
		</form>
	</div>
	</div>
</body>
</html>