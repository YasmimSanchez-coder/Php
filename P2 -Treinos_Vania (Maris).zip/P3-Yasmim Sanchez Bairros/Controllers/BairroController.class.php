<?php
    require_once "Models/Conexao.class.php"; //generico
    require_once "Models/CidadeDAO.class.php";
    require_once "Models/Cidade.class.php";
    require_once "Models/Bairro.class.php";
    require_once "Models/BairroDAO.class.php";
    class BairroController
    {
        public function listar() //metodo
    {
        //criar a conexao
        $BairroDAO = new bairroDAO();
        $retorno = $BairroDAO->buscar_todos();
        //var_dump($retorno);

        //mostra dados buscados
        require_once "Views/Listar.Bairros.php";
    }

    public function alterar($id)
    {
        $erro = "";
            if (!ctype_digit($id)) {
            // Resposta para id inválido
                http_response_code(400); // Bad Request
                echo "ID inválido.";
                return;
            }

            // Converta para inteiro se quiser garantir tipo
            $id = (int)$id;
            $Bairro = new Bairro($id);
            $BairroDAO = new BairroDAO();
            $retorno = $BairroDAO->buscar_todos($Bairro);
            require_once "Views/Edit.bairro.php";
    }

        public function excluir($id)
		{
			$erro = "";
			if (!ctype_digit($id)) {
			// Resposta para id inválido
				http_response_code(400); // Bad Request
				echo "ID inválido.";
				return;
			}

			// Converta para inteiro se quiser garantir tipo
			$id = (int)$id;
			$bairro = new Bairro($id);
			$bairroDAO = new bairroDAO();
			$retorno = $bairroDAO->excluir($bairro);
            header("location:/Bairros/listar");			
		}
    }
?>
