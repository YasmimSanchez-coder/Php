<?php
	class Cidade
	{
		public function __construct(private int $id_cidade = 0, 
        private string $nome = "", private string $uf = "",){}

		public function getId_cidade()
		{
			return $this->id_cidade;
		}
		
		public function getNome()
		{
			return $this->nome;
		}
				
		public function getUf()
		{
			return $this->uf;
		}
	}
?>