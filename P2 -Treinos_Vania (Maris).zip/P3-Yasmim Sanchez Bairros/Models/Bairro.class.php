<?php
	class Bairro
	{
		public function __construct(private int $idbairro = 0, private int $idcidade = 0, 
        private string $nome = "", private string $regiao = "", private string $comentario = ""){}
	
		public function getIdbairro()
		{
			return $this->idbairro;
		}
		
		public function getIdcidade()
		{
			return $this->idcidade;
		}
		
		public function getNome()
		{
			return $this->nome;
		}
		
		public function getRegiao()
		{
			return $this->regiao;
		}
		
		public function getComentario()
		{
			return $this->comentario;
		}
	}
?>