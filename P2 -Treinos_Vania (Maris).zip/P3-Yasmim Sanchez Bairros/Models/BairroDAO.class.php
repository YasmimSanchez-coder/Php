<?php
    class BairroDAO extends Conexao
    {   
        protected $db = null;
        public function __construct()
        {
            parent:: __construct(); 
        }

        public function buscar_todos()
        {
            $sql= "SELECT * FROM bairro"; //tudo sql em maiusculo (Endjoin facil)
            try
            {
                $stm = $this->db->prepare($sql);
                $stm->execute();
                $this->db = null; //fecha conexão
                return $stm->fetchALL(PDO::FETCH_OBJ); //fetchALL = pega tudo
            }
            catch(PDOException $e)
            {
                $this->db = null; //fechar conexão
                return"Problema ao buscar os Bairros";
            }
        }
    }
?>