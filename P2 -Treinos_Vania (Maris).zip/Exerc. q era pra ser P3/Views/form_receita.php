<!DOCTYPE html>
<html>
    <head>
        <title>Receitas</title>
        <meta charset="UTF-8">
    </head>
    <body>
		<h1>Receita</h1>
		<form class="form-control" action="#" method="POST">
			<div>
				<label for="nome">Nome</label>
				<input type="text"  id="nome" name="nome" value="<?php echo isset($_POST['nome'])?$_POST['nome']:''?>">
				<div style="color:red"><?php echo $msg[0] != ""?$msg[0]:'';?></div>
			</div>
			<br><br>
			<div>
				<label for="Ingredientes">Ingredientes</label><br>
				<textarea name="Ingredientes" id="ingredientes"><?php echo isset($_POST['Ingredientes'])?$_POST['Ingredientes']:''?></textarea>
				<div style="color:red"><?php echo $msg[1] != ""?$msg[1]:'';?></div>
			</div>
			<br><br>
			<div >
				<label for="Preparo">Preparo</label>
				<textarea name="Preparo" id="Preparo"<?php echo isset($_POST['Preparo'])?$_POST['Preparo']:''?></textarea>
				<div style="color:red"><?php echo $msg[2] != ""?$msg[2]:'';?></div>
			</div>
			<br><br>
			<div>
				<label for="Chef">Chef</label>
				<select name="Chef" id="Chef">
					<option value="0">Escolha um Chef</option>
					<?php
				foreach($retorno as $dados)
				{
					if(isset($_POST["Chef"]) && $_POST["Chef"] == $dados->id_Chef)
					{
						echo "<option value='{$dados->id_Chef}' selected>{$dados->nome}</option>"; //select: serve pra colocar em 1 lugar a categria já escolhida
					}
					else
					{
						echo "<option value='{$dados->id_Chef}'>{$dados->nome}</option>";
					}
				}//fim do foreach	
					?>
				</select>
				<div style="color:red"><?php echo $msg[3] != ""?$msg[3]:'';?></div>
			</div>
			<br><br>
			<input type="submit" value="Cadastrar">
		</form>
	  </div>
	</div>
</body>
</html>
