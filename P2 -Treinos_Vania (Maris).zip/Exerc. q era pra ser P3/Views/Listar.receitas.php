<?php

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Receitas</title>
        <meta charset="UTF-8">
    </head>
    <body>
	<table border="1">
			<tr>
				<th>Nome</th>
				<th>Ingredientes</th>
				<th>Mode de Preparo</th>
				<th>Chef</th>
				<th>Ações</th>
	</tr>
	<?php
				foreach($retorno as $dados)
				{	
					echo "<tr>
					      <td>{$dados->nome}</td>
						  <td>{$dados->ingredientes}</td>
						  <td>{$dados->modoPreparo}</td>
						  <td>{$dados->chef}</td>
						  <td><a href=''>Alterar</a>
						  &nbsp;&nbsp;";
						  echo "</td>
						 </tr>"; 	  
				}
		?>
		</table>
		</body>
		</html>