<?php
    require_once "Models/Conexao.class.php"; //generico
    require_once "Models/ReceitaDAO.class.php";
    require_once "Models/ChefDAO.class.php";
    require_once "Models/Chef.class.php";
    require_once "Models/Receita.class.php";
    class ReceitaController
    {
        public function listar() //metodo
    {
        //criar a conexao
        $receitaDAO = new receitaDAO();
        $retorno = $receitaDAO->buscar_todas();
        //var_dump($retorno);

        //mostra dados buscados
        require_once "Views/Listar.receitas.php";
    }

        public function inserir()
        {
            $msg = array("","","","");
            if($_POST)
            {
                //Verificações
                //criar o objeto receita
                $chef = new Chef($_POST["chef"]);
                $receita = new Receita(0, $_POST["nome"], $_POST["ingredientes"], 
            $_POST["modoPreparo"], $chef);
                $receitaDAO = new receitaDAO();
                $receitaDAO->inserir_receita($receita);
                header("location:index.php?controle=ReceitaController&metodo=listar");
                die();
            }
            //mostrar a visão pra pegar os dados da receita

            //buscar chefs cadastrados
            $ChefDAO = new ChefDAO();
            $retorno = $ChefDAO->buscar_todos();

            //mostrar view
            require_once "Views/form_receita.php";

            //inserir no banco de dados
        }
    }
?>
