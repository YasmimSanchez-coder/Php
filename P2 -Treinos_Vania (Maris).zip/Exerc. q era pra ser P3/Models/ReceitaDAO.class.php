<?php
    class receitaDAO extends Conexao
    {   
        protected $db = null;
        public function __construct()
        {
            parent:: __construct(); 
        }

        public function buscar_todas()
        {
            $sql= "SELECT r.*, c.nome as chef FROM receita as r, chef as c WHERE r.id_chef= c.id_chef"; //tudo sql em maiusculo (Endjoin facil)
            try
            {
                $stm = $this->db->prepare($sql);
                $stm->execute();
                $this->db = null; //fecha conexão
                return $stm->fetchALL(PDO::FETCH_OBJ); //fetchALL = pega tudo
            }
            catch(PDOException $e)
            {
                $this->db = null; //fechar conexão
                return"Problema ao buscar as receitas";
            }
        }

        public function inserir_receita($receita)
        {
            			
			$sql = "INSERT INTO receita (nome, ingredientes, modoPreparo, id_Chef) VALUES(?,?,?,?)";
			try
			{
			//preparar frase
			$stm = $this->db->prepare($sql);
			//substituir o ponto de interrogação
			$stm->bindValue(1, $receita->getNome());
			$stm->bindValue(2, $receita->getingredientes());
			$stm->bindValue(3, $receita->getmodoPreparo());
			$stm->bindValue(4, $receita->getChef()->getId_chef());
			//executar a frase sql
			$stm->execute();
			//fechar a conexão
			$this->db = null;
			return "Receita cadastrada com sucesso";
			}
			catch(PDOException $e)
			{
				$this->db = null;
				return "Problema ao inserir receita";
			}
        }

    }
?>