<?php
	class Receita
	{
		public function __construct(private int $id_receita = 0, private string $nome = "", 
        private string $ingredientes = "", private string $modoPreparo = "", private $chef = null){}
	
		public function getId_receita()
		{
			return $this->id_receita;
		}
		
		public function getNome()
		{
			return $this->nome;
		}
		
		public function getingredientes()
		{
			return $this->ingredientes;
		}
		
		public function getmodoPreparo()
		{
			return $this->modoPreparo;
		}
		
		public function getChef()
		{
			return $this->chef;
		}
	}
?>