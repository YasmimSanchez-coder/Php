<?php
	$nome = "Yasmim Sanchez Ouvinhas";
	$idade = 19;
	$celular = "(14)991711771";
	$altura = 1.50;
	$namorando = true;
	
	echo "<h3 style='color:blue'>O meu nome é $nome e tenho $idade anos</h3><br>";
	echo "Tenho de altura $altura e meu celular é $celular<br>";
	//verifica se namorando é verdadeiro
	if($namorando)
	{
		echo "tenho namorada";
	}
	else
	{
		echo "NÃO Sou solteira";
	}
	
	
?>