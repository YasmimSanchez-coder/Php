<!--3. Ordenação Manual de um Vetor
Crie um vetor de 3 números e ordene-os manualmente (sem usar sort()), 
comparando e trocando os valores, se necessário.-->

<?php
//Entrada
	$vet = array(10, 5, 7);
	
	//Processamento
	$aux = 0;
	for($x=0; $x < count($vet)-1; $x++)
	{
		for($y=0; $y < count($vet)-1; $y++)
		{
		  if($vet [$y] > $vet[$y+1])
	{
		$aux= $vet[$y];
		$vet[$y] = $vet[$y+1];
		$vet[$y+1] = $aux;
	}
	
	if($vet[1] > $vet[2])
	{
		$auxiliar = $vet[2];
		$vet[2] = $vet[1];
		$vet[1] = $aux;
	}
	
	if($vet[0] > $vet[2])
	{
		$auxiliar = $vet[2];
		$vet[2] = $vet[0];
		$vet[0] = $aux;
	}
	
	//Saída
	foreach($vet as $dado)
	{
		echo "$dado<br>";
	}
		}
	}
?>