<?php
/*2. Somar Elementos de um Vetor
Crie um vetor com 5 números inteiros
e some manualmente os valores acessando cada índice diretamente.*/ 


//entrada
 $vetor = array(1,2,3,4,5);
//processamento
 $soma = 0;
 foreach($vetor as $dados)
 {
	 $soma = $soma + $dado;
	 //$soma += $dados (outra forma)
 }
 //saída
  echo "O valor da soma é $soma";
 ?>