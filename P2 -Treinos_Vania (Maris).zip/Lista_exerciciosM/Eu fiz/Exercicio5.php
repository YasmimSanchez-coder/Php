<!--Tabela de Produtos (Array nomeado)
Crie um array nomeado onde a chave é o nome de um produto e o valor é seu preço. 
Exiba os produtos em uma tabela HTML.-->

<!doctype html>
<html>
	<head>
		<title>Exercício 5</title>
		<meta charset="UTF-8">
		
		<style>
			.space{line-height: 16px;}
		</style>
	</head>
	
	<body>
		<h2>Loja de miçangas</h2>
		<table>
			<tr>
				<tr>
					<?php
						$nomes = array("Preta", "Vermelha", "Branca");
						$valor = array(1.50, 1.55, 1.50);
						
						echo "Produtos: <br>";
						
						foreach($nomes as $produto)
						{
							echo "$produto<br>";
						}
					
						echo "<br>";
						
						echo "Preços: <br>";
						
						foreach($valor as $preço)
						{
							echo "$preço<br>";
						}
					?>
				</tr>
			</tr>
		</table>
	</body>
</html>