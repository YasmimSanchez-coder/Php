<!--6. Média de Notas dos Alunos
Armazene as notas de 2 alunos 
(cada um com 3 notas) e exiba a média de cada um.-->

<?php
	//Array com as notas das alunas
	$notas = array(array("Rayssa", 5.5, 7.0, 9.0), 
					array("Yasmim", 10.0, 6.0, 8.0)
					);
					
		for($lin=0; $lin < 2; $lin++)
		{
			for($col=0; $col < 4; $col++)
			{
			 echo "{$notas[$lin][$col]}<br>";
			}
		}


	//Array que tem só as Notas
	$notasGeral = [5.5, 7.0, 9.0, 10.0, 6.0, 8.0];
	
	//Função para calcular a Média
	function calcularMedia($notasGeral) {
		$totalNotas = count($notasGeral);
		$somaNotas = array_sum($notasGeral);
		
		if($totalNotas > 0) {
			$media = $somaNotas / $totalNotas;
			return $media;
		} else{
			return 0;
		}
	}
	
	echo"<br><br>";
	
	//Calacula a média
	$media = calcularMedia($notasGeral);
	
	//Mostra as notas
	echo "Média de alunos: " . number_format($media, 2);
?>