<!doctype html>
<html>
    <head>
	 <title>Exercicio 1</title>
	 <meta charset="UTF-8">
	</head>
	<body>
	</!--1. Exibir um Vetor Simples
    Crie um vetor com 5 nomes e exiba-os em uma lista ul no HTML.(assim que comenta no html)-->
	    <h3>Lista de Nomes</h3>
		<ul>
		<?php
		$nomes = array("Yasmim", "Rayssa", "Marina", "Tamires", "Kaike");
		foreach($nomes as $nome)
		{
			echo "<li>$nome</li>";
		}
		?>
		</ul>
	</body>
 </html>