<!--10. Criar uma Agenda Simples
Crie uma matriz nomeada para armazenar 3 contatos 
(nome, telefone e e-mail) e exiba os dados acessando os índices diretamente.-->

<?php
	$agenda = array(array("Clara", 99763875, "clara@gmail.com"), 
					array("Pedro", 22678359, "pedro@gmail.com"), 
					array("Henrique", 45628729, "henrique@gmail.com")
					);
	
	/*
	for($lin=0; $lin < 3; $lin++) 
	{
		for($col=0; $col < 3; $col++)
		{
		 echo "{$agenda[$lin][$col]}<br>";
		}
	}
	*/
	
	echo"<br>";
	
	foreach($agenda as $vetor)
	{
		foreach($vetor as $dado)
		{
			echo "$dado<br>";
		}
	}
?>