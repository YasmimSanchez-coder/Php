<?php
	class inicioController
	{
		// essa função e o CONTROLLER em si é usado apenas para exibir o menu, como se fosse uma "tela inicial"
		public function inicio()
		{
			require_once "views/menu.php";
		}
	}
?>