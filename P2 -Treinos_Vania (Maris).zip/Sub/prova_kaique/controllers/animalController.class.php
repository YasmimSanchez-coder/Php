<?php
	// importando as classes necessárias pro controller funcionar
	require_once "models/Conexao.class.php";
	require_once "models/Animal.class.php";
	require_once "models/animalDAO.class.php";
	require_once "models/Avistamento.class.php";
	require_once "models/avistamentoDAO.class.php";

	class animalController
	{
		// Tanto essa função/método quanto o CONTROLLER de animal não foram necessários para fazer nada na prova, tanto que a VIEW "listar_animais.php" nem existe. Eu fiz na hora por 
		// achar que talvez fosse necessário, e não apaguei aqui apenas pra você conseguir entender a minha lógica aqui
		public function listar()
		{
			$animalDAO = new animalDAO();
			// buscando método buscar_animais() que está dentro de "models/animalDAO.class.php"
			$retorno = $animalDAO -> buscar_animais();

			require_once "views/listar_animais.php";
		}
	}
	
?>