<?php
	// importando as classes necessárias pro controller funcionar
	require_once "models/Conexao.class.php";
	require_once "models/Animal.class.php";
	require_once "models/animalDAO.class.php";
	require_once "models/Avistamento.class.php";
	require_once "models/avistamentoDAO.class.php";

	class avistamentoController
	{
		public function listar()
		{
			// instanciando um novo avistamentoDAO para conseguir armazenar dentro da variável $avistamentos o resultado final ao puxar o método "buscar_todos()",
			// que está lá dentro de models/avistamentoDAO.class.php"!
			$avistamentoDAO = new avistamentoDAO();
			$avistamentos = $avistamentoDAO -> buscar_todos();
			
			// instanciando um novo animalDAO para conseguir armazenar dentro da variável $animais o resultado final ao puxar o método "buscar_animais()",
			// que está lá dentro de models/animalDAO.class.php"!
			$animalDAO = new animalDAO();
			$animais = $animalDAO -> buscar_animais();
			
			// exibindo a view listar_avistamentos, que dentro dela, terá todas as informações fornecidas acima para você usar a vontade no HTML
			require_once "views/listar_avistamentos.php";
		}
		
		public function inserir()
		{
			// instanciando um novo animalDAO para conseguir armazenar dentro da variável $animais o resultado final ao puxar o método "buscar_animais()",
			// que está lá dentro de models/animalDAO.class.php"! isso é necessário porque no form_avistamento.php temos um SELECT de animais, por isso, precisamos saber
			// quais são os animais registrados dentro do banco para que a pessoa consiga escolher nesse SELECT
			$animalDAO = new animalDAO();
			$animais = $animalDAO -> buscar_animais();

			// variáveis para verificação de erros, como campos vazios no form
			$msg = ["", "", ""];
			$erro = false;
			
			// SE tiver um POST (preencher os dados do formulário e clicar no botão enviar), entra aqui
			if ($_POST)
			{
				// verificando se os valores dos INPUTS que estão lá no "views/form_avisamentos.php" estão vazios, para evitar de criar um Avistamento vazio no banco
				if (empty($_POST["data_avistamento"]))	// OBS: aqui dentro do $_POST é o mesmo nome que você colocou em "name" lá no input
				{
					// se for vazio, enviará essa mensagem e transforma $erro em TRUE
					$msg[0] = "Por favor, selecione uma data";
					$erro = true;
				}

				if (empty($_POST["local_avistamento"]))
				{
					// se for vazio, enviará essa mensagem e transforma $erro em TRUE
					$msg[1] = "Por favor, indique o local";
					$erro = true;
				}

				if (empty($_POST["animais"]))
				{
					// se for vazio, enviará essa mensagem e transforma $erro em TRUE
					$msg[2] = "Por favor, escolha um animal";
					$erro = true;
				}

				// criando um novo avistamento com a classe Avistamento e armazenando na variável $avistamento
                $avistamento = new Avistamento
                ( 
					// é necessário passar todos os atributos de acordo com a ordem que está lá dentro da classe Avistamento, mas o valor do ID pode ser 0 mesmo por ser automático
					0,
					// a partir daqui, estamos pegando os valores enviados via método POST para enviar
					$_POST["animais"],
					$_POST["data_avistamento"], 
					$_POST["perigo"],
					$_POST["local_avistamento"]
                );
					
				// novo avistamentoDAO para conseguir enviar o avistamento que fizemos agora mesmo para dentro do banco
                $avistamentoDAO = new AvistamentoDAO();
                $avistamentos = $avistamentoDAO -> inserir($avistamento);

				// após enviar os dados, redireciona para listar_avistamentos
				header("location:index.php?controle=avistamentoController&metodo=listar");
			}

			// exibindo a view de form_avistamento com toas as informações acima armazenadas dentro dela
			require_once "views/form_avistamentos.php";
		}
	}
	
?>