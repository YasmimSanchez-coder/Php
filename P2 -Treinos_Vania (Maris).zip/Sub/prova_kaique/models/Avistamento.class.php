<?php 

	class Avistamento
	{
		public function __construct
		(
			// atributos da classe! 	INT = Inteiro	STRING = Texto
			private int $idAvistamento = 0, 
			// $idanimais é um atributo da classe, mas que verdadeiramente vem de outra classe (Animal.class.php), então a forma de guardá-lo é assim
			private $idanimais = null,
			private string $data_avistamento = "",
			private string $perigo = "",
			private string $local_avistamento = ""
		){}
		
		// Métodos GET, o nome da função pode ser qualquer um
		public function getIdAvistamento()
		{
			// o nome após a seta que aparece aqui deve ser exatamente igual o nome do atributo da classe que ele se refere, nesse caso, "idAvistamento"
			return $this -> idAvistamento;
		}
		
		public function getIdAnimais()
		{
			// o nome após a seta que aparece aqui deve ser exatamente igual o nome do atributo da classe que ele se refere, nesse caso, "idanimais"
			return $this -> idanimais;
		}
		
		public function getData()
		{
			// o nome após a seta que aparece aqui deve ser exatamente igual o nome do atributo da classe que ele se refere, nesse caso, "data_avistamento"
			return $this -> data_avistamento;
		}
		
		public function getPerigo()
		{
			// o nome após a seta que aparece aqui deve ser exatamente igual o nome do atributo da classe que ele se refere, nesse caso, "perigo"
			return $this -> perigo;
		}
		
		public function getLocal()
		{
			// o nome após a seta que aparece aqui deve ser exatamente igual o nome do atributo da classe que ele se refere, nesse caso, "local_avistamento"
			return $this -> local_avistamento;
		}
	}

?>