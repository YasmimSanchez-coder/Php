<?php 

	class Animal
	{
		public function __construct
		(
			// atributos da classe! 	INT = Inteiro	STRING = Texto
			private int $idanimais = 0, 
			private string $nome = "",
			private string $especie = ""
		){}
		
		// Métodos GET, o nome da função pode ser qualquer um
		public function getIdAnimais()
		{
			// o nome após a seta que aparece aqui deve ser exatamente igual o nome do atributo da classe que ele se refere, nesse caso, "idanimais"
			return $this -> idanimais;
		}
		
		public function getNome()
		{
			// o nome após a seta que aparece aqui deve ser exatamente igual o nome do atributo da classe que ele se refere, nesse caso, "nome"
			return $this -> nome;
		}
		
		public function getEspecie()
		{
			// o nome após a seta que aparece aqui deve ser exatamente igual o nome do atributo da classe que ele se refere, nesse caso, "especie"
			return $this -> especie;
		}
	}

?>