<?php
	// "Extends" significa que há uma relação de HERANÇA! Está herdando da classe "Conexão" para conseguir acessar o banco e realizar mudanças na tabela de Avistamentos
	class avistamentoDAO extends Conexao
	{
		public function __construct()
		{
			// como está herdando, é necessário deixar explícito a herança do construtor da classe pai
			parent:: __construct();
		}
		
		// método para INSERIR animais dentro do banco, é necessário passar um OBJETO avistamento, dentro da variável $avistamento
		public function inserir($avistamento)
		{
			// salvando código SQL para inserção dos dados fornecidos em uma variável $sql
			$sql = "INSERT INTO avistamentos (idanimais, data_avistamento, perigo, local_avistamento) 
			VALUES(?, ?, ?, ?)"; // as "?" são por segurança, os valores serão preenchidos logo abaixo
			try 
			{
				// pegando a variável $sql e trocando os "?" por valores verdadeiros, usando os GET() que existem dentro da classe avistamento, para conseguir
				// pegar os dados fornecidos. Não esquece de trocar o número do bindValue! Precisa ser na mesma ordem!
				$stm = $this -> db -> prepare($sql);
				$stm -> bindValue(1, $avistamento -> getIdAnimais());
				$stm -> bindValue(2, $avistamento -> getData());
				$stm -> bindValue(3, $avistamento -> getPerigo());
				$stm -> bindValue(4, $avistamento -> getLocal());
				$stm -> execute();

				$this -> db = null;
				return "Avistamento inserido com sucesso";
			}
			catch(PDOException $e) 
			{
				$this -> db = null;
				return "Problema ao inserir avistamento";
			}	
		}
		
		public function buscar_todos()
		{
			// INNERJOIN para juntar a tabela AVISTAMENTOS e ANIMAIS, para exibir tudo de uma vez
			// av é avistamento		an é animal
			$sql = "SELECT av.*, an.* 
			FROM avistamentos AS av
			INNER JOIN animais AS an ON av.idanimais = an.idanimais";
			try
			{
				$stm = $this -> db -> prepare($sql);
				$stm -> execute();
				$this -> db = null;
				return $stm -> fetchAll(PDO::FETCH_OBJ);
			}
			catch(PDOException $e)
			{
				$this -> db = null;
				return "Problema ao buscar";
			}
		}
	}//fim da classe avistamentoDAO
?>