<?php
	// "Extends" significa que há uma relação de HERANÇA! Está herdando da classe "Conexão" para conseguir acessar o banco e realizar mudanças na tabela de Animais
	class animalDAO extends Conexao
	{
		public function __construct()
		{
			// como está herdando, é necessário deixar explícito a herança do construtor da classe pai
			parent:: __construct();
		}
		
		// método para INSERIR animais dentro do banco, é necessário passar um OBJETO animal, dentro da variável $animal
		public function inserir($animal)
		{
			// salvando código SQL para inserção dos dados fornecidos em uma variável $sql
			$sql = "INSERT INTO animais (nome, especie) 
			VALUES(?, ?)";	// as "?" são por segurança, os valores serão preenchidos logo abaixo
			
			try 
			{
				// pegando a variável $sql e trocando os "?" por valores verdadeiros, usando o getNome() e getEspecie() que existem dentro da classe animal, para conseguir
				// pegar os dados fornecidos. Não esquece de trocar o número do bindValue! Precisa ser na mesma ordem!
				$stm = $this -> db -> prepare($sql);
				$stm -> bindValue(1, $animal -> getNome());
				$stm -> bindValue(2, $animal -> getEspecie());
				$stm -> execute();

				$this -> db = null;
				return "Animal inserido com sucesso";
			}
			catch(PDOException $e) 
			{
				$this -> db = null;
				return "Problema ao inserir animal";
			}	
		}
		
		// método para buscar TODOS os animais, é simplesmente um SELECT * FROM animais (selecionar TUDO de animais)
		public function buscar_animais()
		{
			$sql = "SELECT * FROM animais";
			try
			{
				$stm = $this -> db -> prepare($sql);
				$stm -> execute();

				$this -> db = null;
				return $stm -> fetchAll(PDO::FETCH_OBJ);
			}
			catch(PDOException $e) 
			{
				$this -> db = null;
				return "Problema ao buscar os animais";
			}
		}
	} //fim da classe animalDAO
?>