<?php
	require_once "header.php";
?>
	<div class="content">
	<div class="container">
		<br><br><h1>Lista de Avistamentos</h1><br>
		<!-- Início da Tabela AVISTAMENTOS --> 
		<table class="table table-striped">
			<tr>
				<th>Data</th>
				<th>Perigo</th>
				<th>Local</th>
				<th>Id do Animal</th>
				<th>Nome do Animal</th>
				<th>Espécie</th>
			</tr>
			<?php	
				// pegando os $avistamentos do banco e exibindo-os um por um
				foreach($avistamentos as $dados)
				{
					echo "<tr>
							<td>{$dados -> data_avistamento}</td>
							<td>{$dados -> perigo}</td>
							<td>{$dados -> local_avistamento}</td>
							<td>{$dados -> idanimais}</td>
							<td>{$dados -> nome}</td>
							<td>{$dados -> especie}</td>";
						"</tr>";
				} // Fim do ForEach
			?>
		</table><br><br>
		<!-- Fim da Tabela AVISTAMENTOS --> 
		
		<br><br><h1>Lista de Animais</h1><br>
		<!-- Inicio da Tabela ANIMAIS --> 
		<table class="table table-striped">
			<tr>
				<th>Nome</th>
				<th>Espécie</th>
			</tr>
			<?php	
				// pegando os $animais do banco e exibindo-os um por um
				foreach($animais as $dados)
				{
					echo "<tr>
							<td>{$dados -> nome}</td>
							<td>{$dados -> especie}</td>
						</tr>";
				}
			?>
		</table>
		<!-- Fim da Tabela ANIMAIS --> 

		<!-- Ao clicar aqui, irá chamar o método INSERIR do avistamentoController, que por não ter tido nenhum POST, irá apenas te redirecionar 
		para a página de form_avistamentos.php --> 
		<br><a href="index.php?controle=avistamentoController&metodo=inserir" class="btn btn-success">Novo Avistamento</a>
	</div>
</div>