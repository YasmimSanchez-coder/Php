<?php
	// require para exibir a header
	require_once "header.php";
?>
	<div class = "content">
		<div class = "container">
		<br>
			<h1>Avistamento</h1>
			<br>
			<!-- INÍCIO do FORM. No ACTION, deve fornecer qual o método que ele irá despertar caso o form seja preenchido e enviado. Nesse caso, ao apertar 
			no botão enviar, ele irá primeiramente acessar o avistamentoController e em seguida puxará o método Inserir() do avistamentoController -->
			<form action="index.php?controle=avistamentoController&metodo=inserir" method="post">
				<label for="data_avistamento">Data do Avistamento:</label>
				<input type="date" name="data_avistamento" id="data_avistamento">
				<!-- Mensagem de erro, caso não seja preenchido --> 
				<p style="color: red; font-size: 15px;"><?php echo $msg[0] ?></p>
				
				<label for="local_avistamento">Local do Avistamento:</label>
				<input type="text" name="local_avistamento" id="local_avistamento">
				<!-- Mensagem de erro, caso não seja preenchido --> 
				<p style="color: red; font-size: 15px;"><?php echo $msg[1] ?></p>

				<!-- Abaixo é um SELECT, que puxa TODOS os animais cadastrados no banco para exibi-los, para selecionar na hora de cadastrar um novo avistamento -->
				<div class="mb-3">
					<label for="animais" class="form-label">Animais:</label>
					<select name="animais" id="animais">
						<option value="0">Escolha um animal</option>
					<?php
					// A variável $animais desse ForEach está dentro do inserir() lá no avistamentoController
					foreach($animais as $dados)
					{
						if(isset($_POST["animais"]) && $_POST["animais"] == $dados -> idanimais)
						{
							echo "<option value='{$dados -> idanimais}' selected>{$dados -> nome}</option>";
						}
						else
						{
							echo "<option value='{$dados -> idanimais}'>{$dados -> nome}</option>";
						}
					}
							
						?>
					</select>
					<!-- Mensagem de erro, caso não seja preenchido --> 
					<p style="color: red; font-size: 15px;"><?php echo $msg[2] ?></p>
				</div>
				
				<!-- Abaixo está outro SELECT, mas superficial, pois não cadastramos os tipos de perigos diretamente pelo banco igual foi com os animais -->
				<div class="mb-3">
					<label for="perigo" class="form-label">Perigo:</label>
					<select name="perigo" id="perigo">
						<option value="Não">Não</option>
						<option value="Sim">Sim</option>
					</select>
				</div>
				
				<!-- Botão de Enviar -->
				<input type="submit" value="Enviar" class="btn btn-success">
			</form> <!-- FIM do FORM -->
		</div>
	</div>
</body>
</html>