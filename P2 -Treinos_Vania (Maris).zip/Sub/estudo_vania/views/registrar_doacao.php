<?php
    $pagina = "Registrar Doações";
    require_once("header.php");
?>
    <h1>Registrar Doacao</h1>
    <form action="index.php?controle=doacao&metodo=registrar" method="post">
        <label for="valor_doacao">Valor Doacao</label></br>
        <input type="number" name="valor_doacao" id="valor_doacao" step="0.01" min="0.00"></br>
        <p style="color: red;"><?php echo $msg[0]?></p></br>

        <label for="data_doacao">Data Doacao</label></br>
        <input type="date" name="data_doacao" id="data_doacao"></br>
        <p style="color: red;"><?php echo $msg[1]?></p></br>
        
        <label for="tipo_doacao">Tipo Doação</label></br>
        <input type="text" name="tipo_doacao" id="tipo_doacao"></br>
        <p style="color: red;"><?php echo $msg[2]?></p></br>
        
        <label for="id_doador">Doador</label></br>
        <select name="id_doador" id="id_doador">
            <option value="" selected disabled>- Selecione uma Opção</option>
            <?php
                foreach($doadores as $doador){
                    echo "<option value='{$doador["id"]}'>{$doador["nome"]}</option>";
                }
            ?>
        </select></br>
        <p style="color: red;"><?php echo $msg[3]?></p></br>
        <button type="submit">Registrar</button>
    </form>
</main>
</body>
</html>