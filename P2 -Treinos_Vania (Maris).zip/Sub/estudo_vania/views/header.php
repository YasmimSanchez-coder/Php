<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doações - <?php echo $pagina?></title>
</head>
<body>
<header>
    <h1><a href="index.php">Doações</a></h1>
    <nav>
        <ul>
            <li><a href="index.php">Menu</a></li>
            <li><a href="index.php?controle=doacao&metodo=listar">Listar Doações</a></li>
            <li><a href="index.php?controle=doacao&metodo=registrar">Registrar Doações</a></li>
        </ul>
    </nav>
</header>
<main>