<?php
	require_once("models/DoacaoDAO.class.php");
	require_once("models/DoadorDAO.class.php");

	class doacaoController
	{
		public function listar()
		{
            //echo "<h1>Estou em Listar (doacaoController)</h1>";
			$doadorDAO = new DoadorDAO();
			$doadores = $doadorDAO->listar();
			$doacaoDAO = new DoacaoDAO();
			$doacoes = $doacaoDAO->listar();
			require_once("views/listar_doacoes.php");
		}
        public function registrar()
		{
            //echo "<h1>Estou em registrar (doacaoController)</h1>";
			$msg = ["", "", "", ""];
			if($_POST){
				$valor = floatval($_POST["valor_doacao"]);
				$data = $_POST["data_doacao"];
				$tipo = $_POST["tipo_doacao"];
				$erro = 0;
				$doador = empty($_POST["id_doador"]) ? 0 : intval($_POST["id_doador"]);

				if(empty($valor) || $valor < 0){
					$msg[0] = "Valor Inválido";
					$erro = 1;
				}
				$doadorDAO = new DoadorDAO();
				$doadores_quant = $doadorDAO->contar();
				if(!(1 <= $doador && $doador < $doadores_quant)){
					$msg[3] = "Doador não Encontrado";
					$erro = 1;
				}
				if($erro = 0){
					$doadorDAO = new DoadorDAO();
					$doadorDAO->registrar();
				}
			}
			$doadorDAO = new DoadorDAO();
			$doadores = $doadorDAO->listar();
			require_once("views/registrar_doacao.php");
		}
        public function alterar()
		{
            echo "<h1>Estou em Alterar (doacaoController)</h1>";
			require_once "views/menu.php";
		}
        public function deletar()
		{
            echo "<h1>Estou em Deletar (doacaoController)</h1>";
			require_once "views/menu.php";
		}
	}
?>