<?php
    require_once("Conexao.class.php");

    class DoadorDAO extends Conexao {
        public function __construct(){
            parent::__construct();
        }
        public function listar(){
            $sql = "SELECT iddoador AS id, nome, contato FROM doadores;";
            try {
                $stm = $this->db->query($sql);
                $resultado = $stm->fetchAll(PDO::FETCH_ASSOC);
                $this->db = null;
                return $resultado;
            } catch(PDOException $e) {
                $this->db = null;
                echo $e;
                return;
            }
        }
        public function contar(){
            $sql = "SELECT COUNT(iddoador) AS doadores_quant FROM doadores;";
            try {
                $stm = $this->db->query($sql);
                $resultado = $stm->fetchAll(PDO::FETCH_ASSOC);
                var_dump($resultado[0]["doadores_quant"]);
                $this->db = null;
                return $resultado[0]["doadores_quant"];
            } catch(PDOException $e) {
                $this->db = null;
                echo $e;
                return;
            }
        }
        /*private function busca($sql){
            try {
                echo $sql;
                $stm = $this->db->query($sql);
                $resultado = $stm->fetchAll(PDO::FETCH_ASSOC)
                $this->db = null;
                return $resultado;
            } catch(PDOException $e) {
                $this->db = null;
                echo $e;
                return;
            }
        }*/
    }
?>