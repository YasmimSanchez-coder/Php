<?php
    require_once("Conexao.class.php");

    class DoacaoDAO extends Conexao {
        public function __construct(){
            parent::__construct();
        }
        public function listar(){
            $sql = "SELECT iddoador, valor, data_doacao, tipo_doacao FROM doacoes;";
            $stm = $this->db->query($sql);
            return $stm->fetchAll();
        }
        public function registrar(){
            $sql = "INSERT INTO avistamentos (idanimais, data_avistamento, perigo, local_avistamento) 
			VALUES(?, ?, ?, ?)";
			try 
			{
				$stm = $this->db->prepare($sql);
				$stm->bindValue(1, $avistamento -> getIdAnimais());
				$stm->bindValue(2, $avistamento -> getData());
				$stm->bindValue(3, $avistamento -> getPerigo());
				$stm->bindValue(4, $avistamento -> getLocal());
				$stm->execute();

				$this->db = null;
				return "Avistamento inserido com sucesso";
			}
			catch(PDOException $e) 
			{
				$this -> db = null;
				return "Problema ao inserir avistamento";
			}	
        }
    }
?>