<?php
	class Avistamentos
	{
		public function __construct(private int $idAvistamento = 0, private int $id_animal = 0, private string $dataAvistamento = "", 
        private string $perigo = "", private string $local= ""){}
		
		public function getidAvistamento()
		{
			return $this->idAvistamento;
		}

        public function setidAvistamento()
		{
			$this->idAvistamento = $idAvistamento;
		}

		public function getId_animal()
		{
			return $this->Id_animal;
		}

		public function getdataAvistamento()
		{
			return $this->dataAvistamento;
		}

        public function getperigo()
		{
			return $this->perigo;
		}

        public function getlocal()
		{
			return $this->local;
		}
	}
?>