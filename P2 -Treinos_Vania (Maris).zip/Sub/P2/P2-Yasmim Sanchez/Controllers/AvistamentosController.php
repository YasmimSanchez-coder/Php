<?php
class AvistamentoSController
	{
		public function listar()
		{
			//buscar os dados no banco
			$Avistamento = new Avistamento();
			$retorno = $Avistamento->buscar_todos();
			require_once "Views/listarAvistamento.php";
			//mostra a view
		}//fim do método listar
		public function inserir()
		{
			$erro = "";
			if($_POST)
			{
				//verificar se descrição preenchida
				if(empty($_POST["descritivo"]))
				{
					$erro = "Preencha o descritivo";
				}
				else
				{
					//inserir a nova categoria no bd
					$Avistamento = new Avistamento(0,$_POST["descritivo"]);
					
					$Avistamento = new Avistamento();
					$retorno = $categoriaDAO->inserir($categoria);
					header("Views/listarAvistamento.php");
				}
			}
			require_once "Views/listarAvistamento.php";
		}
		public function alterar($id)
		{
			$erro = "";
				if (!ctype_digit($id)) {
				// Resposta para id inválido
					http_response_code(400); // Bad Request
					echo "ID inválido.";
					return;
				}

				// Converta para inteiro se quiser garantir tipo
				$id = (int)$id;
				$categoria = new Categoria($id);
				$categoriaDAO = new categoriaDAO();
				$retorno = $categoriaDAO->buscar_uma_categoria($categoria);
				
			
			require_once "Views/listarAvistamento.php";
		}
		public function edit()
		{
			$erro = "";
			if($_POST)
			{
				if(empty($_POST["descritivo"]))
				{
					$erro = "Preencha o descritivo";
				}
				else
				{
					//alterar a categoria no bd
					$categoria = new Categoria($_POST["id_categoria"],$_POST["descritivo"]);
					
					$categoriaDAO = new categoriaDAO();
					$retorno = $categoriaDAO->alterar($categoria);
					header("Views/listarAvistamento.php");
				}
			}
			
			require_once "Views/listarAvistamento.php";
		}
		public function excluir($id)
		{
			$erro = "";
			if (!ctype_digit($id)) {
			// Resposta para id inválido
				http_response_code(400); // Bad Request
				echo "ID inválido.";
				return;
			}

			// Converta para inteiro se quiser garantir tipo
			$id = (int)$id;
			$categoria = new Categoria($id);
			$categoriaDAO = new categoriaDAO();
			$retorno = $categoriaDAO->excluir($categoria);
			header("Views/listarAvistamento.php");
			
		}
	}//fim da classe
?>