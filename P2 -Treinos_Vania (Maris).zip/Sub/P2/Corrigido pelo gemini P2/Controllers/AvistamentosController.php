<?php
class AvistamentosController
{
    public function listar()
    {
        // 1. Pega os dados do Modelo (DAO)
        $avistamentoDAO = new AvistamentoDAO();
        $avistamentos = $avistamentoDAO->buscarTodos();

        // 2. Chama a Visão (View) para mostrar os dados
        require_once "Views/listarAvistamento.php";
    }

    public function form_inserir()
    {
        // Para o formulário, precisamos da lista de animais para o <select>
        $animalDAO = new AnimalDAO();
        $animais = $animalDAO->buscarTodos();

        // Chama a View do formulário
        require_once "Views/form_Avistamento.php";
    }

    public function inserir()
    {
        // Verifica se os dados foram enviados pelo formulário
        if ($_POST) {
            // Cria um novo objeto Avistamentos com os dados do POST
            $avistamento = new Avistamentos(
                0, // id é autoincremento
                $_POST['idanimais'],
                $_POST['data_avistamento'],
                $_POST['perigo'],
                $_POST['local_avistamento']
            );

            // Pede para o DAO inserir no banco
            $avistamentoDAO = new AvistamentoDAO();
            $avistamentoDAO->inserir($avistamento);

            // Redireciona para a página de listagem
            header("Location: /listar");
        }
    }
}
?>