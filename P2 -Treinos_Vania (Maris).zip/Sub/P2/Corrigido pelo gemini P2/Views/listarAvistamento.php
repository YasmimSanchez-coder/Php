<h1>Lista de Avistamentos</h1>
<a href="/form_inserir" class="btn btn-success mb-3">Novo Avistamento</a>
<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>Data</th>
            <th>Local</th>
            <th>Animal</th>
            <th>Espécie</th>
            <th>Em Perigo?</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($avistamentos as $avistamento): ?>
            <tr>
                <td><?= date("d/m/Y", strtotime($avistamento->data_avistamento)) ?></td>
                <td><?= htmlspecialchars($avistamento->local_avistamento) ?></td>
                <td><?= htmlspecialchars($avistamento->nome) ?></td>
                <td><?= htmlspecialchars($avistamento->especie) ?></td>
                <td><?= htmlspecialchars(ucfirst($avistamento->perigo)) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>