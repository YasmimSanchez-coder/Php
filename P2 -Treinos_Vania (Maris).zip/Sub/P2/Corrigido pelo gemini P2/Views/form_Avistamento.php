<h1>Inserir Novo Avistamento</h1>
<form action="/inserir" method="post">
    <div class="mb-3">
        <label for="data_avistamento" class="form-label">Data do Avistamento:</label>
        <input type="date" class="form-control" name="data_avistamento" id="data_avistamento" required>
    </div>
    <div class="mb-3">
        <label for="local_avistamento" class="form-label">Local:</label>
        <input type="text" class="form-control" name="local_avistamento" id="local_avistamento" required>
    </div>
    <div class="mb-3">
        <label for="idanimais" class="form-label">Animal:</label>
        <select class="form-select" name="idanimais" id="idanimais" required>
            <option value="">Selecione um animal</option>
            <?php foreach ($animais as $animal): ?>
                <option value="<?= $animal->idanimais ?>"><?= $animal->nome ?> (<?= $animal->especie ?>)</option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Animal em Perigo?</label>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="perigo" id="perigo_sim" value="sim" required>
            <label class="form-check-label" for="perigo_sim">Sim</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="perigo" id="perigo_nao" value="nao">
            <label class="form-check-label" for="perigo_nao">Não</label>
        </div>
    </div>
    <button type="submit" class="btn btn-primary">Salvar</button>
</form>