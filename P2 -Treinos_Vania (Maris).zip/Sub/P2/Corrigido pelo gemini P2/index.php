<?php
// index.php com roteador simples
session_start();
require_once "Views/Cabecalho.php"; // Cabeçalho vem primeiro

spl_autoload_register(function($class){
    if(file_exists("Models/".$class.".class.php")) require_once "Models/".$class.".class.php";
    else if(file_exists("Controllers/".$class.".php")) require_once "Controllers/".$class.".php";
});

$rota = $_GET['rota'] ?? 'inicio';

switch($rota){
    case 'listar':
        $controller = new AvistamentosController();
        $controller->listar();
        break;
    case 'form_inserir':
        $controller = new AvistamentosController();
        $controller->form_inserir();
        break;
    case 'inserir':
        $controller = new AvistamentosController();
        $controller->inserir();
        break;
    default:
        echo "<h2>Página Inicial</h2><p>Use o menu para navegar.</p>";
        break;
}
?>