<?php
require_once "Conexao.php";
require_once "Avistamentos.class.php";

class AvistamentoDAO extends Conexao
{
    public function buscarTodos()
    {
        // A prova pedia os dados do avistamento E do animal. O JOIN faz isso.
        $sql = "SELECT Avistamentos.*, animais.nome, animais.especie 
                FROM Avistamentos 
                INNER JOIN animais ON Avistamentos.idanimais = animais.idanimais 
                ORDER BY data_avistamento DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        // Retorna um array de objetos, onde cada objeto tem os dados do avistamento e do animal.
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function inserir(Avistamentos $avistamento)
    {
        $sql = "INSERT INTO Avistamentos (idanimais, data_avistamento, perigo, local_avistamento) 
                VALUES (?, ?, ?, ?)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(1, $avistamento->getIdanimais());
        $stmt->bindValue(2, $avistamento->getData_avistamento());
        $stmt->bindValue(3, $avistamento->getPerigo());
        $stmt->bindValue(4, $avistamento->getLocal_avistamento());
        
        return $stmt->execute();
    }
}
?>