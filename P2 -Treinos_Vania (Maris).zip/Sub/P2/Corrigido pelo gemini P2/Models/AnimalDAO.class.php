<?php
require_once "Conexao.php";

class AnimalDAO extends Conexao
{
    public function buscarTodos()
    {
        $sql = "SELECT * FROM animais ORDER BY nome";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
}
?>