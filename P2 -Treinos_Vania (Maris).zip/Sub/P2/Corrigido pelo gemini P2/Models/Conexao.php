<?php
	abstract class Conexao
	{
		protected $db = null;
		
		public function __construct()
		{
			$parametros = "mysql:host=localhost;dbname=avistamentos;charset=utf8mb4";
			try
			{
				$this->db = new PDO($parametros,"root", "");
			}
			catch(PDOException $e)
			{
                // Correção: Mostra as mensagens de erro e DEPOIS encerra.
				echo "ERRO: ".$e->getMessage();
                echo "CÓDIGO: ".$e->getCode();
                die("<br>Problema com conexão do banco de dados");
			}
		}
	}
?>