<?php
class Avistamentos
{
    // Propriedades com nomes iguais aos da tabela SQL
    public function __construct(
        private int $idAvistamentos = 0, 
        private int $idanimais = 0, 
        private string $data_avistamento = "", 
        private string $perigo = "", 
        private string $local_avistamento = ""
    ){}

    // Getters para todas as propriedades
    public function getIdAvistamentos() { return $this->idAvistamentos; }
    public function getIdanimais() { return $this->idanimais; }
    public function getData_avistamento() { return $this->data_avistamento; }
    public function getPerigo() { return $this->perigo; }
    public function getLocal_avistamento() { return $this->local_avistamento; }
}
?>