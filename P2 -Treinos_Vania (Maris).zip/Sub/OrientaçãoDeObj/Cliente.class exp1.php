<?php
	class Cliente
	{
		public string $nome;
		public string $cpf;
		public string $celular;
	}
	
	$cliente1 = new Cliente();
	$cliente1->nome = "Paulo da Silva"; //Como o "nome" é atributo ele não fica "$nome"
	$cliente1->cpf = "111.111.111-11";
	$cliente1->celular = "(14) 996936628";
	echo "<pre>";
	var_dump($cliente1);
	echo "</pre>";
	
	$cliente2 = new Cliente();
	$cliente2->nome = "Paulo da Silva"; //Como o "nome" é atributo ele não fica "$nome"
	$cliente2->cpf = "222.222.222-22";
	$cliente2->celular = "(14) 997715789";
	echo "<pre>";
	var_dump($cliente2);
	echo "</pre>";
?>