<?php
	require_once "Class.Usuario.Php";
	require_once "Class.Celular.Php";
	
	$usuario1 = new Usuario ("Vera", "111.111.111-11", 
	"vera@gmail.com", 14, "123456");
	
	$usuario1->setCelular(15, "9899292");
	
	/*echo"<pre>";
	var_dump($usuario1);
	echo"</pre>";*/
	
	echo "<h1>Usuário 1</h1>";
	echo "Nome: {$usuario1->getNome()}<br>";
	echo "CPF: {$usuario1->getCpf()}<br>";
	echo "E-mail: {$usuario1->getEmail()}<br>";
	echo "Celulare(s)<br>";
	foreach($usuario1->getCelular() as $celular)
	{
		echo "({$celular->getDdd()})
			{$celular->getNumero()}<br>";
	}
?>