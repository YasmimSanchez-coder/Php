<?php
	class Usuario
	{
		public function __construct(private string $nome= "",
		private string $cpf = "", private string $email = "", $ddd, $numero)
			{
				$this->celular[] = new Celular($ddd,$numero);
			}
		public function getNome()
		{
			return $this->nome;
		}
		
		public function getCpf()
		{
			return $this->cpf;
		}
		
		public function getEmail()
		{
			return $this->email;
		}
		
		public function setCelular($ddd, $numero)
		{
			$this->celular[] = new Celular($ddd, $numero);
		}
		
		public function getCelular()
		{
			return $this->celular;
		}
	}
?>