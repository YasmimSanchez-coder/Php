<?php
	class Produto
	{
		public function __construct (private string $nome = "", 
		private string $descricao = "", private float $preco = 0.00,
		private array $fornecedor = array()){} //não inicializa sem =
		
		public function getNome()
		{
			return $this->nome;
		}
		
		public function getDescricao()
		{
			return $this->descricao;
		}
		
		public function getPreco()
		{
			return $this->preco;
		}
		
		public function getFornecedor()
		{
			return $this->fornecedor;
		}
	
		public function setFornecedor(Fornecedor $fornecedor)
		//o $nome, SEMPRE precisa ser o mesmo em baixo por exemplo forn precisa ser em baixo tbm
		{
			$this->fornecedor[] = $fornecedor;
		}
	}
?>