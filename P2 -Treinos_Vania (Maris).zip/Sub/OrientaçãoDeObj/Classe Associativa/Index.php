<?php
	require_once "Classe.ator.php";
	require_once "Classe.filme.php";
	require_once "Classe.atuacao.php";
	
	$ator1 = new Ator("Leonardo", "Americana"); //esses vem sempre antes
	$filme1 = new Filme ("Titanic", "2 Horas");
	$filme2 = new Filme ("Ilha do medo", "1 hora e 50 min");
	
	$atuacao1 = new Atuacao ("Jack", $filme1, $ator1); //desse
	
	echo "Filme: {$atuacao1 -> getFilme() -> getTitulo()}<br>";
	echo "Duração: {$atuacao1 -> getFilme()-> getDuracao()}<br>";
	echo "Ator: {$atuacao1 -> getAtor() ->getNome()}<br>";
	echo "Nacionalidade: {$atuacao1 -> getAtor() -> getNacionalidade()}<br>"; //todo get precisa do= () após ele
	echo "Papel: {$atuacao1 -> getPapel()}<br>";
?>