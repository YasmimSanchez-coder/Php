<?php
//para dizer qm é o pai (extends)
  class contaPoupança extends Conta
  {
	  //filha e vamos chamar a classe pai (conta)
	  public function __construct(private int $aniversario = 0, 
	  string $agencia,string $conta,string $saldo) //precisa colocar os atributos da class pai
		  {
			parent::__construct($agencia, $conta, $saldo); //chama a class pai
		  }
	public function sacar ($valor)
	{
         $data = explode("/", date("y/m/d"));
		 if($data[2] > $this->aniversario && $this->saldo >= $valor)
		 {
			 parent::sacar($valor);
		 }
		 else
		 {
			 echo "Problema no saque";
		 }
	}
	  public function getAniversario()
	  {
		  return $this->aniversario;
	  }
	  
	  public function setAniversario ($aniversario)
	  {
		  $this->aniversario = $aniversario;
	  }
  }
?>