<?php
	require_once "Class.Produto.Php";
	require_once "Class.Categoria.Php";
	
	$categoria1 = new Categoria("Material Escolar"); //aqui sempre anets de usar precisa estar antes
	$categoria2 = new Categoria("Material de Escritório");
	$produto1 = new Produto ("Lapís preto", 2.50, array($categoria1)); 
	                                             //quando 2 colocar as 2 nesse lugar
	$produto2 = new Produto ("Caderno", 10.00, array($categoria1));
	
	//aqui faz depois de instanciar o objeto pra adiconar mais 1 ao objeto
	//$produto->setCategoria($categoria2); 
	//tem q estar criado antes, precisa criar primeiro dps usar e precisa criar DEPOIS de o produto criado
	
	/*echo"<pre>";
	var_dump($produto1);
	echo"</pre>";
	
	echo"<br><br><pre>";
	var_dump($produto2);
	echo"</pre>";*/
	
	echo "<h1>Produto 1</h1>";
	echo "Nome: {$produto1->getNome()}<br>";
	echo "Preço: {$produto1->getPreco()}<br>";
	echo "Categoria (s) <br>";
	foreach($produto1->getCategoria() as $categoria)
	{
		echo "Descritivo: {$categoria->getDescritivo()}<br>";
	}
?>