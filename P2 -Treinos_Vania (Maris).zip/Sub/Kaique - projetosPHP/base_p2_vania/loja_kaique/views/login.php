<?php 
	require_once "header.php"; 
?>	

<!DOCTYPE html>
<html>

<head>
	<title>Loja - Login</title>
	<meta charset="UTF-8">
</head>

	<div class="content">
	<div class="container">
	<h1>Login</h1>
	<br>
	<form action="#" method="POST">
		<label>E-mail:</label>
		<input type="email" name="email"/>
		<br><br>
		
		<label>Senha</label>
		<input type="password" name="senha"/>
		<br><br>
		
		<input type="submit" value="Enviar"/>
	</form>
</body>

</html>