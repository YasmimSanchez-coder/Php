# Sobre o Projeto

Fogo Zero é um Projeto do curso de Desenvolvimento de Software Multiplataforma, desenvolvido na Fatec Jaú pelos alunos: Kaique, Marina e Tamires.

O objetivo desse projeto é de auxiliar os usuários do website a ter informações relacionadas a queimadas próximas a sua região, além de oferecer a possibilidade de denúncia de incidentes não registrados.
