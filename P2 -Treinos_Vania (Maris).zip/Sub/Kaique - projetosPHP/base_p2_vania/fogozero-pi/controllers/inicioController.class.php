<?php
	class inicioController
	{
		public function inicio()
		{
			require_once "views/tela-inicial.php";
		}

		public function cadastro()
		{
			$msg = ["", "", "", ""];
			require_once "views/cadastro.php";
		}

		public function login()
		{
			require_once "views/login.php";
		}

		public function educacao()
		{
			require_once "views/educacao.php";
		}

		public function quemsomos()
		{
			require_once "views/quemsomos.php";
		}
	}
?>