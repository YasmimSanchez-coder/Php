<?php
    require_once "header.php";
?>  

    <section class="quem-somos">
        <div class="container">
            <h1>Quem Somos</h1>
            <p>
                Somos uma equipe de estudantes apaixonados por tecnologia, natureza e inovação. O <strong>Fogo Zero</strong> nasceu do desejo de transformar conhecimento acadêmico em impacto real, unindo esforços para proteger nossas florestas e comunidades contra os riscos dos incêndios.
            </p>
        </div>
    </section>

    <section class="container py-5">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h2 class="mb-4">Nossa História</h2>
                <p>
                    Em 2024, um grupo de estudantes da FATEC Jahu se uniu para desenvolver um projeto acadêmico voltado à prevenção de incêndios florestais. O que começou como um desafio de sala de aula se tornou uma missão de vida.<br><br>
                </p>
                <p>
                    Com o apoio da comunidade acadêmica e o desejo de causar impacto positivo, nasceu o <strong>FogoZero</strong>: uma iniciativa que alia tecnologia, educação ambiental e responsabilidade social.<br><br>
                </p>
                <p>
                    Hoje, seguimos evoluindo como uma equipe multidisciplinar, comprometida em desenvolver soluções acessíveis para proteger vidas e o meio ambiente.
                </p>
            </div>
            <div class="col-lg-6">
                <img src="img/quemsomos.jpg" alt="Equipe Fogo Zero trabalhando" class="img-fluid rounded shadow">
            </div>
        </div>
    </section>

    <section class="nossa-missao">
        <div class="container">
            <h2 class="text-center mb-5">Nossa Missão</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card-missao">
                        <i class="fas fa-fire-extinguisher"></i><br><br>
                        <h3>Combate a Incêndios</h3>
                        <p>Desenvolver tecnologias que ajudem no combate rápido e eficiente aos incêndios florestais, minimizando danos ambientais.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-missao">
                        <i class="fas fa-bell"></i><br><br>
                        <h3>Sistema de Alertas</h3>
                        <p>Criar um sistema de alerta precoce para comunidades em risco, permitindo evacuações rápidas e organizadas.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-missao">
                        <i class="fas fa-graduation-cap"></i><br><br>
                        <h3>Educação Ambiental</h3>
                        <p>Promover a conscientização sobre prevenção de incêndios e preservação ambiental através de programas educativos.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="equipe">
        <div class="container">
            <h2 class="text-center mt-5 mb-5">Nossa Equipe</h2>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="membro-equipe">
                        <img src="https://avatars.githubusercontent.com/u/181370670?v=4" alt="Marina Frankin">
                        <h3>Marina Frankin</h3>
                        <p class="funcao">Desenvolvedora de Software</p>
                        <p>Integrante do projeto Fogo Zero.</p>
                        <div class="redes-sociais">
                            <a href="https://www.linkedin.com/in/marina-frankin-340811321/"><i class="fab fa-linkedin"></i></a>
                            <a href="https://github.com/marinafrankin"><i class="fab fa-github"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="membro-equipe">
                        <img src="https://avatars.githubusercontent.com/u/96202019?v=4" alt="Tamires Talier">
                        <h3>Tamires Talier</h3>
                        <p class="funcao">Desenvolvedora de Software</p>
                        <p>Integrante do projeto Fogo Zero.</p>
                        <div class="redes-sociais">
                            <a href="https://www.linkedin.com/in/tamires-talier-de-oliveira-73b050203/"><i class="fab fa-linkedin"></i></a>
                            <a href="https://github.com/tamirestalier"><i class="fab fa-github"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="membro-equipe">
                        <img src="https://avatars.githubusercontent.com/u/99449012?v=4" alt="Kaique Onencio">
                        <h3>Kaique Onencio</h3>
                        <p class="funcao">Desenvolvedor de Software</p>
                        <p>Integrante do projeto Fogo Zero.</p>
                        <div class="redes-sociais">
                            <a href="https://www.linkedin.com/in/kaique-onencio"><i class="fab fa-linkedin"></i></a>
                            <a href="https://github.com/kaiqsou"><i class="fab fa-github"></i></a>
                            <a href="https://www.instagram.com/kaiqsou/"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div><br><br><br><br><br>

            <div class="text-center mt-5">
               
            </div>
        </div>
    </section>

    <section class="bg-light py-5 text-center">
        <div class="container">
            <br><br> <h3 class="mb-4">Desenvolvimento de Software Multiplataforma</h3>
                <p>2º Semestre - FATEC Jahu</p>
                <p>Orientadora: Prof. Vânia Somaio Teixeira</p><br><br><br>
                <img src="img/fatec-logo.png" alt="Logo da Fatec" class="img-fluid d-block mx-auto">
        </div>
    </section>

</body>
</html>
<?php
    require_once "footer.php";      
?>