<?php
class Festa
{
    // O construtor está perfeito como você fez.
    public function __construct(
        private string $data_contrato = "", 
        private string $data_festa = "", 
        private float $valor = 0.00,
        private array $contratado = array(), 
        private ?Cliente $cliente = null,
        private ?Decoracao $decoracao = null
    ) {}

    // --- MÉTODOS GETTER QUE ESTAVAM FALTANDO ---

    public function getData_contrato()
    {
        return $this->data_contrato;
    }

    public function getData_festa()
    {
        return $this->data_festa;
    }

    public function getValor()
    {
        return $this->valor;
    }

    public function getContratado()
    {
        return $this->contratado;
    }

    public function getCliente()
    {
        return $this->cliente;
    }

    // --- Seus métodos de Decoração (que já estavam certos) ---
    public function getDecoracao()
    {
        return $this->decoracao;
    }

    public function setDecoracao(Decoracao $decoracao)
    {
        $this->decoracao = $decoracao;
    }


    // --- MÉTODO MOSTRAR DADOS ---
    // Agora este método vai funcionar, pois todas as funções que ele chama existem.
    public function mostrarDados()
    {
        echo "Data da festa: {$this->getData_festa()}<br>";
        echo "Data do contrato: {$this->getData_contrato()}<br>";
        echo "Valor: R$ " . number_format($this->getValor(), 2, ',', '.') . "<br>";
        
        if ($this->getCliente()) {
            echo "Cliente: {$this->getCliente()->getNome()}<br>";
            echo "Telefone do Cliente: ";
            foreach ($this->getCliente()->getTelefone() as $telefone) {
                echo "({$telefone->getDdd()}) {$telefone->getNumero()} ";
            }
            echo "<br>";
        }

        if ($this->getDecoracao()) {
            echo "Decoração: {$this->getDecoracao()->getDescritivo()}<br>";
        }

        echo "<h4>Contratados:</h4>";
        if (empty($this->getContratado())) {
            echo "Nenhum contratado associado.<br>";
        } else {
            foreach ($this->getContratado() as $contratado) {
                echo "- Nome: {$contratado->getNome()} | CNPJ: {$contratado->getCnpj()} | Telefone: ";
                foreach ($contratado->getTelefone() as $telefone) {
                    echo "({$telefone->getDdd()}) {$telefone->getNumero()} ";
                }
                echo "<br>";
            }
        }
    }
}
?>