<?php
    class Contratado extends Pessoa
    {
        public function __construct(private string $cnpj = "", string $nome = "")
        { // <-- Chave de abertura que faltava

            // Passa o nome para o construtor da classe "mãe" (Pessoa)
            parent::__construct($nome); // <-- Ponto e vírgula que faltava

        } // <-- Chave de fechamento que faltava

        // É uma boa prática já adicionar o getter para o CNPJ também
        public function getCnpj()
        {
            return $this->cnpj;
        }

        public function setCnpj($cnpj)
        {
            $this->cnpj = $cnpj;
        }
    }
?>