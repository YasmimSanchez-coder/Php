<?php
// É bom ter o require_once da classe que será usada no tipo
require_once "Class.Pessoa.php";

class Telefone
{
    // Adicionamos o tipo "Pessoa" e o "?" que significa que a propriedade pode ser do tipo Pessoa ou nula.
    public function __construct(
        private int $ddd = 0, 
        private string $numero = "", 
        private ?Pessoa $pessoa = null
    ) {}

    public function getDdd()
    {
        return $this->ddd;
    }

    public function setDdd($ddd)
    {
        $this->ddd = $ddd;
    }

    public function getNumero()
    {
        return $this->numero;
    }

    public function setNumero($numero)
    {
        $this->numero = $numero;
    }

    public function getPessoa()
    {
        return $this->pessoa;
    }

    // Para consistência, se temos um getPessoa, é bom ter um setPessoa também.
    public function setPessoa(Pessoa $pessoa)
    {
        $this->pessoa = $pessoa;
    }
}
?>