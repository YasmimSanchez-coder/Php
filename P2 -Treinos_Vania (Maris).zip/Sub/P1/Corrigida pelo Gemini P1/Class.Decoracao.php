<?php
class Decoracao
{
    public function __construct(private string $descritivo = "") {}

    public function getDescritivo()
    {
        return $this->descritivo;
    }

    // Corrigimos o nome do método e da variável para serem consistentes
    public function setDescritivo($descritivo)
    {
        $this->descritivo = $descritivo;
    }
}
?>