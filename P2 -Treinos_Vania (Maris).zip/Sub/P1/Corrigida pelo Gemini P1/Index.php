<?php
    // --- CARREGANDO TODAS AS CLASSES NECESSÁRIAS ---
    // A ordem é importante para a herança (mãe antes da filha)

    // 1. Classes independentes ou "mães"
    require_once "Class.Pessoa.php";
    require_once "Class.Decoracao.php";
    require_once "Class.Telefone.php";

    // 2. Classes "filhas" que dependem das anteriores
    require_once "Class.Cliente.php";    // Precisa que Pessoa já seja conhecido
    require_once "Class.Contratado.php"; // Precisa que Pessoa já seja conhecido

    // 3. Classe principal que usa as outras
    require_once "Class.Festa.php";      // Precisa de Cliente, Contratado, etc.

    // AGORA SIM! O PHP já leu todas as "plantas" e sabe construir qualquer objeto.
    // O resto do seu código, que já está certo, vem aqui...

    // --- Montando o Cliente ---
    $cliente = new Cliente("764.986.126-94", "Gabriela Santos");
    $cliente->addTelefone(14, "993456789");

    // --- Montando os Contratados ---
    $contratado1 = new Contratado("87391-27", "Marina");
    $contratado1->addTelefone(14, "994354789");

    $contratado2 = new Contratado("26391-11", "Clara");
    $contratado2->addTelefone(14, "992906345");

    // --- Montando a Decoração ---
    $decoracao = new Decoracao("Temática de Super-Heróis");

    // --- Instanciando a Festa e Associando os Objetos ---
    $festa1 = new Festa(
        "17/10/2024", 
        "27/10/2024", 
        10000,
        [$contratado1, $contratado2], // Array de contratados
        $cliente,                    // Objeto Cliente
        $decoracao                   // Objeto Decoracao
    );

    // --- Mostrando os dados de forma encapsulada ---
    echo "<h2>Dados da Festa 1</h2>";
    $festa1->mostrarDados();

?>