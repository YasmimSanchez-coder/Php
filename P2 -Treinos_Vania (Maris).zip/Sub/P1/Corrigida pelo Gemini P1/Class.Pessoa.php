<?php
// É bom ter o require_once da classe que será usada no tipo
require_once "Class.Telefone.php";

class Pessoa
{
    // A propriedade de telefone que já tínhamos feito
    protected array $telefone = [];

    // O construtor moderno e limpo
    public function __construct(protected string $nome = "")
    {
    }

    // O MÉTODO PÚBLICO QUE ESTAVA FALTANDO!
    public function getNome()
    {
        return $this->nome;
    }

    // É uma boa prática também ter o "setter"
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    // O método de adicionar telefone que já tínhamos feito
    public function addTelefone(int $ddd, string $numero)
    {
        $this->telefone[] = new Telefone($ddd, $numero, $this);
    }

    // E o getter para o telefone
    public function getTelefone()
    {
        return $this->telefone;
    }
}
?>