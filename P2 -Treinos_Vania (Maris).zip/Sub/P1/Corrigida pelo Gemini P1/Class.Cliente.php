<?php
// Em um arquivo real, é bom ter o require_once da classe mãe
require_once "Class.Pessoa.php";

// 1. Adicionamos o "extends Pessoa" para criar a relação de herança
class Cliente extends Pessoa
{
    public function __construct(private string $cpf = "", string $nome = "")
    { // <-- 2. Chave de abertura

        // A sua lógica aqui está perfeita!
        // Passa o nome para o construtor da classe "mãe" (Pessoa)
        parent::__construct($nome); // <-- 3. Ponto e vírgula

    } // <-- Chave de fechamento

    // Getters e Setters para o CPF
    public function getCpf()
    {
        return $this->cpf;
    }

    public function setCpf($cpf)
    {
        $this->cpf = $cpf;
    }
}
?>