<?php
    class Contratado extends Pessoa
    {
        public function __construct(private string $cnpj = "", $nome, $ddd, $numero, $pessoa, private array $festa = array())

        {
            parent:: __construct($nome, $ddd, $numero, $pessoa);
        }

        public function getCnpj()
        {
            return $this->cnpj;
        }

        public function setCnpj($cnpj)
        {
            $this->cnpj = $cnpj;
        }

        public function getFesta()
        {
            return $this->cnpj;
        }

        public function setFesta(Festa $festa)
        {
            $this->festa[] = $festa;
        }
    }
?>