<?php
    class Festa
    {
        public function __construct(private string $data_contrato = "", private string $data_festa, private float $valor = 0.00, 
        private array $contratado = array(), private Cliente $cliente = new Cliente(), private array $decoracao = array()){}

        public function getData_contrato()
        {
            return $this->data_contrato;
        }

        public function setData_contrato($data_contrato)
        {
            $this->data_contrato = $data_contrato;
        }

        public function getData_festa()
        {
            return $this->data_festa;
        }

        public function setData_festa($data_festa)
        {
            $this->data_festa = $data_festa;
        }

        public function getValor()
        {
            return $this->valor;
        }

        public function setValor($valor)
        {
            $this->valor = $valor;
        }

        public function getContratado()
        {
            return $this->contratado;
        }

        public function setContratado(Contratado $contratado)
        {
            $this->contratado[] = $contratado;
        }

        public function getCliente()
        {
            return $this->cliente;
        }

        public function getDecoracao()
        {
            return $this->decoracao;
        }

        public function setDecoracao($decoracao)
        {
            $this->decoracao[] = $decoracao;
        }
    }
?>