<?php
    class Cliente extends Pessoa
    {
        public function __construct(private string $cpf = "", $nome, $ddd, $numero, $pessoa)

        {
            parent:: __construct($nome, $ddd, $numero, $pessoa);
        }

        public function getCpg()
        {
            return $this->cpf;
        }

        public function setCpf()
        {
            $this->cpf = $cpf;
        }
    }
?>