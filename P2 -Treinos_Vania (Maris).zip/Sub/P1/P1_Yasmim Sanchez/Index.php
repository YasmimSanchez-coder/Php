<?php
    require_once "Class.Pessoa.php";
    require_once "Class.Festa.php";
    require_once "Class.Cliente.php";
    require_once "Class.Contratado.php";
    require_once "Class.Decoracao.php";
    require_once "Class.Telefone.php";


    $cliente = new Cliente("764.986.126-94", "Gabriela Santos", 14, "993456789", null);
    
    $contratado1 = new Contratado("87391-27", "Marina", 14, "994354789", array());
    $contratado2 = new Contratado("26391-11", "Clara", 14, "992906345", array());
    $contratado3 = new Contratado("81294-93", "Ana  Julia", 14, "993682964", array());
    $contratado4 = new Contratado("12345-75", "Marcos", 14, "995456739", array());

    $decoracao = new Decoracao("Temática");

    $festa = new Festa("17/10/2024", "27/10/2024", 10000, array($contratado1, $contratado3), $cliente, array($decoracao));
    $festa2 = new Festa("21/05/2025", "03/06/2025", 15000, array($contratado2, $contratado4), $cliente, array($decoracao));

    //Mostrar dados
    echo "<h2>Festa1</h2>";
    echo "Data da festa: {$festa->getData_festa()}<br>";
    echo "Data do contrato: {$festa->getData_contrato()}<br>";
    echo "Valor: {$festa->getValor()}<br>";
    echo "Cliente: {$cliente->getNome()}<br>";
    foreach($cliente->getTelefone() as $telefone)
    {
        echo "({$telefone->getDdd()}){$telefone->getNumero()}<br>";
    }
    echo "Decoracao: {$decoracao->getDescritivo()}<br>";

    $cont = 0;
    foreach($festa->getContratado() as $contratado1)
    {
        $cont++;
        echo "<h4>Contratado$cont</h4>";
        echo "Nome: {$contratado1->getNome()}<br>";
        echo "Cnpj: {$contratado1->getCnpj()}<br>";
        foreach($contratado1->getTelefone() as $telefone)
        {
        echo "({$telefone->getDdd()}){$telefone->getNumero()}<br><br>";
        }
    }

    //festa2
    echo "<h2>Festa2</h2>";
    echo "Data da festa: {$festa2->getData_festa()}<br>";
    echo "Data do contrato: {$festa2->getData_contrato()}<br>";
    echo "Valor: {$festa2->getValor()}<br>";
    echo "Cliente: {$cliente->getNome()}<br>";
    foreach($cliente->getTelefone() as $telefone)
    {
        echo "({$telefone->getDdd()}){$telefone->getNumero()}<br>";
    }
    echo "Decoracao: {$decoracao->getDescritivo()}<br>";

    $cont2 = 0;
    foreach($festa2->getContratado() as $contratado2)
    {
        $cont2++;
        echo "<h4>Contratado$cont2</h4>";
        echo "Nome: {$contratado2->getNome()}<br>";
        echo "Cnpj: {$contratado2->getCnpj()}<br>";
        foreach($contratado2->getTelefone() as $telefone)
        {
        echo "({$telefone->getDdd()}){$telefone->getNumero()}<br><br>";
        }
    }
?>