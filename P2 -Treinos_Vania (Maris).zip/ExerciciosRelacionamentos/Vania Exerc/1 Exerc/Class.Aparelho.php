<?php
    class Aparelho
    {
        public function __construct(private string $descritivo = "",private Modelo $modelo = new Modelo, private Cliente $cliente = new Cliente, private array $tecnico = array()){}

        public function getDescritivo()
		{ 
			return $this->descritivo;
		}
		
		public function getModelo()
		{ 
			return $this->modelo;
		}
		
        public function setDescritivo(string $descritivo) //tipado (tem que ser igual ao que está na outra class)
		{ 
			$this->descritivo = $descritivo; 
		}
		
		public function setModelo($modelo) //objeto modelo
		{ 
			$this->modelo = $modelo;
		}
		
		public function getCliente()
		{ 
			return $this->cliente;
		}
		
		public function setCliente($cliente) //sem tipar
		{ 
			$this->cliente = $cliente; 
		}
		
			
		public function getTecnico()
		{ 
			return $this->tecnico;
		}
		
		public function setTecnico($tecnico) // quando é arrary
		{ 
			$this->tecnico[] = $tecnico; 
		}
    }
?>