<?php
	abstract class Pessoa
	{
		public function __construct(protected string $nome = "",
		$ddd, $numero)
		{ 
			$this->telefone[] = new Telefone($ddd, $numero);
		}
		
		public function getNome()
		{
		return $this->nome;
		}
		
		public function setNome()
		{
		$this-> nome = $nome;
		}
		
		public function getTelefone()
		{
		return $this->telefone;
		}
		
		public function setTelefone(int $ddd, string $numero)
		{
		$this-> telefone = new Telefone($ddd, $numero);
		}
	}
?>