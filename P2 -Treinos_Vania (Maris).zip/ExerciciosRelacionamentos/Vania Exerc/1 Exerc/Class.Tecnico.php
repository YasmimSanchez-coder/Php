<?php
class Tecnico extends Pessoa
{
	public function __construct (private string $especialidade = "", private array $aparelho = array(), $nome, $ddd, $numero)
	{
		parent :: __construct($nome, $ddd, $numero);
	}
	
		public function getEspecialidade()
		{
		return $this->especialidade;
		}
		
		public function setEspecialidade()
		{
		$this-> especialidade = $especialidade;
		}
		
		public function getAparelho()
		{ 
			return $this->aparelho;
		}
		
		public function setAparelho($aparelho) // quando é arrary
		{ 
			$this->aparelho[] = $aparelho;  //quando arrray PRECISA []
		}
}
?>