<?php

    class Modelo
    {
		public function __construct(private $descritivo = ""){} //precisa valor inicial

        public function getDescritivo()
		{ 
			return $this->descritivo; 
		}
		
		public function setDescritivo($descritivo)
		{ 
			$this->descritivo = $descritivo;
		}
    }

?>