<?php
	require_once "Class.Pessoa.php"; //caso tipe a ordem importa
	require_once "Class.Cliente.php";
	require_once "Class.Tecnico.php";
	require_once "Class.Aparelho.php";
	require_once "Class.Modelo.php";
	require_once "Class.Orcamento.php";
	require_once "Class.Telefone.php";
	
	$modelo = new Modelo("Motorola 4444");
	
	$cliente = new Cliente ("111.111.111-11","Yasmim Sanchez", 14, "123456");
	
	$aparelho = new Aparelho ("Celular", $modelo, $cliente);
	
	$tecnico = new Tecnico("Conserto de Celular", array(), "Valdir",
	14, "321456");
	
	$orcamento = new Orcamento("14/05/2025", 150.60, "20/05/2025", $aparelho, $tecnico);

		echo "<h2>Orçamento</h2>";
		echo "Data do Orçamento: {$orcamento->getData_orcamento()}<br>";
		echo "Data de Validade: {$orcamento->getData_validade()}<br>";
		echo "Preço: R$ ".number_format($orcamento->getPreco(),2,",",".")
		. "<br>";
		
		echo "<h3>Aparelho</h3>";
		echo "Aparelho: {$orcamento->getAparelho()->getDescritivo()}<br>";
		echo "Modelo: {$orcamento->getAparelho()->getModelo()->getDescritivo()}<br>";
		
		echo "<h4>Cliente</h4>";
		echo "Nome: {$orcamento->getAparelho()->getCliente()->getNome()}<br>";
		echo "Cpf: {$orcamento->getAparelho()->getCliente()->getCpf()}<br>";
		foreach($orcamento->getAparelho()->getCliente()->getTelefone() as $telefone)
		{
			echo "({$telefone->getDdd()}){$telefone->getNumero()}<br>";
		}
		
		echo "<h4>Técnico</h4>";
		echo "Nome: {$orcamento->getTecnico()->getNome()}<br>";
		echo "Especialidade: {$orcamento->getTecnico()->getEspecialidade()}<br>";
		foreach($orcamento->getTecnico()->getTelefone() as $telefone)
		{
			echo "({$telefone->getDdd()}){$telefone->getNumero()}<br>";
		}
		
	

	/*
	-string ="" 
	-data do dia é $orcamento = new Orcamento(date(d/m/y")
	-quando pega info ($oq pega) precisa ser antes do que precisa como tec e orcamento
	-privado = get
	-getAparelho = objeto aparelho
	-getDescricao = nome aparelho
	-foreach = varios
	*/

?>