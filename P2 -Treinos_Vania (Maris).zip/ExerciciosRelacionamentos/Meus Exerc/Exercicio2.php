<?php
class Hospede {
    public string $nome;
    public string $cpf;
    public string $telefone;

    public function __construct(string $nome, string $cpf, string $telefone) {
        $this->nome = $nome;
        $this->cpf = $cpf;
        $this->telefone = $telefone;
    }
}
class Funcionario {
    public string $nome;
    public string $cargo;
    public function __construct(string $nome, string $cargo) {
        $this->nome = $nome;
        $this->cargo = $cargo;
    }
}
class Quarto {public string $descricao;public string $numero;
    public function __construct(string $descricao, string $numero) {
        $this->descricao = $descricao;
        $this->numero = $numero;
    }
}
class Reserva {public string $Reserva; public float $preco;
    public string $Estadia;public Hospede $hospede;
    public Funcionario $funcionario;public Quarto $quarto;
    public function __construct(string $Reserva,
    float $preco, string $Estadia, Hospede $hospede,
    Funcionario $funcionario, Quarto $quarto
    ) {
        $this->Reserva = $Reserva;
        $this->preco = $preco;
        $this->estadia = $Estadia;
        $this->hospede = $hospede;
        $this->funcionario = $funcionario;
        $this->quarto = $quarto;
    }
    public function exibirReservaCompleta() {
        echo "<h2>Sobre a reserva</h2>";
        echo "<strong>Data da Reserva:</strong> $this->Reserva<br>";
        echo "<strong>preco:</strong> R$ " . number_format($this->preco, 2, ',', '.') . "<br>";
        echo "<strong>Período:</strong> $this->estadia<br><br>";
        echo "<h3>Hóspede</h3>";
        echo "Nome: {$this->hospede->nome}<br>";
        echo "CPF: {$this->hospede->cpf}<br>";
        echo "Telefone: {$this->hospede->telefone}<br><br>";
        echo "<h3>Fúncionario encarregado</h3>";
        echo "Nome: {$this->funcionario->nome}<br>";
        echo "Cargo: {$this->funcionario->cargo}<br><br>";
        echo "<h3>Informações do qarto</h3>";
        echo "Descrição: {$this->quarto->descricao}<br>";
        echo "Número: {$this->quarto->numero}<br>";
    }
}
$hospede = new Hospede("Rafael Souza Mendes", "321.654.987-10", "(31) 99876-5432");
$funcionario = new Funcionario("Carolina Ramos", "Supervisora de Reservas");
$quarto = new Quarto("Apartamento luxo com vista para o mar", "305B");
$reserva = new Reserva("06/05/2025", 850.00, "20 a 23 de maio", $hospede, $funcionario, $quarto);
$reserva->exibirReservaCompleta();
?>