<?php
class Cliente {
    public string $nome; public string $cpf; public string $telefone;
    public function __construct(string $nome, string $cpf, string $telefone) {
        $this->nome = $nome;
        $this->cpf = $cpf;
        $this->telefone = $telefone;
    }
}
class Tecnico {public string $nome; public string $especialidade;
    public function __construct(string $nome, string $especialidade) {
        $this->nome = $nome;
        $this->especialidade = $especialidade;
    }
}
class Aparelho {public string $descricao; public string $modelo;
    public function __construct(string $descricao, string $modelo) {
        $this->descricao = $descricao;
        $this->modelo = $modelo;
    }
}
class Orcamento { public string $data_Emissao; public float $preco;
    public string $data_Validade; public Cliente $cliente;
    public Tecnico $tecnico; public Aparelho $aparelho;
    public function __construct(string $data_Emissao,
    float $preco,string $data_Validade, Cliente $cliente,
    Tecnico $tecnico, Aparelho $aparelho){
        $this->data_Emissao = $data_Emissao;
        $this->preco = $preco;
        $this->data_Validade = $data_Validade;
        $this->cliente = $cliente;
        $this->tecnico = $tecnico;
        $this->aparelho = $aparelho;
    }
    public function Orcamento() {
        echo "<h2>Orçamento total</h2>";
        echo "<strong>Data de Emissão:</strong> $this->data_Emissao<br>";
        echo "<strong>Valor Total:</strong> R$ " . number_format($this->preco, 2, ',', '.') . "<br>";
        echo "<strong>Validade:</strong> $this->data_Validade<br><br>";
        echo "<h3>Dados do cliente</h3>";
        echo "Nome: {$this->cliente->nome}<br>";
        echo "CPF: {$this->cliente->cpf}<br>";
        echo "Telefone: {$this->cliente->telefone}<br><br>";
        echo "<h3>Tecnico</h3>";
        echo "Nome: {$this->tecnico->nome}<br>";
        echo "Especialidade: {$this->tecnico->especialidade}<br><br>";
        echo "<h3>Sobre o aparelho</h3>";
        echo "Descrição: {$this->aparelho->descricao}<br>";
        echo "Modelo: {$this->aparelho->modelo}<br>";
    }
}
$cliente = new Cliente("Amanda Costa Silva", "456.789.123-00", "(21) 91234-5678");
$tecnico = new Tecnico("Fernando Mendes Rocha", "Manutenção de Impressoras");
$aparelho = new Aparelho("Impressora com atolamento frequente de papel", "HP LaserJet Pro M404dn");
$orcamento = new Orcamento("27/04/2025", 275.50, "06/05/2025", $cliente, $tecnico, $aparelho);
$orcamento->Orcamento();
?>