<?php
	require_once "../Models/Conexao.class.php";
	require_once "../Models/Usuario.class.php";
	require_once "../Models/UsuarioDAO.class.php";
	
	$msg = array("","","","","");
	$erro = false;
	if($_POST)
	{
		if(empty($_POST["nome"]))
		{
			$msg[0] = "Preencha o nome";
			$erro = true;
		}
		if(empty($_POST["celular"]))
		{
			$msg[1] = "Preencha o celular";
			$erro = true;
		}
		if(empty($_POST["email"]))
		{
			$msg[2] = "Preencha o e-mail";
			$erro = true;
		}
		if(empty($_POST["senha"]))
		{
			$msg[3] = "Preencha a senha";
			$erro = true;
		}
		if(empty($_POST["confirma"]))
		{
			$msg[4] = "Confirme a senha";
			$erro = true;
		}
		if($_POST["senha"]!= "" && $_POST["confirma"] != "")
		{
			if($_POST["senha"] != $_POST["confirma"])
			{
				$msg[3] = "Senhas não conferem";
				$erro = true;
			}
		}
		if(!$erro)
		{
			$usuario = new Usuario(0, $_POST["nome"], $_POST["celular"], $_POST["email"], md5($_POST["senha"]));
			$usuarioDAO = new UsuarioDAO();
			$retorno = $usuarioDAO->inserir($usuario);
			echo $retorno;
		}
	}
?>
<!doctype html>
<html>
	<head>
		<title>Pets</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<h1>Usuário</h1>
		<form action="#" method="post">
			<label>Nome:</label>
			<input type="text" name="nome">
			<div class="erro"><?php echo $msg[0]; ?></div><br>
			
			<label>Celular:</label>
			<input type="text" name="celular">
			<div class="erro"><?php echo $msg[1]; ?></div><br>
			
			<label>E-mail:</label>
			<input type="text" name="email">
			<div class="erro"><?php echo $msg[2]; ?></div><br>
			
			<label>Senha:</label>
			<input type="password" name="senha">
			<div class="erro"><?php echo $msg[3]; ?></div><br>
			
			<label>Confirma a senha:</label>
			<input type="text" name="confirma">
			<div class="erro"><?php echo $msg[4]; ?></div><br>
			
			<input type="submit" value="Cadastrar">
			
		</form>
	</body>
</html>