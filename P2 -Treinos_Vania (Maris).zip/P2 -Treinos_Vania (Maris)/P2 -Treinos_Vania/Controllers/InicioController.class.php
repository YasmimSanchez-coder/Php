<?php
    class InicioController
    {
        public function inicio()
        {
            require_once "Views/menu.php";
        }
    }
?>