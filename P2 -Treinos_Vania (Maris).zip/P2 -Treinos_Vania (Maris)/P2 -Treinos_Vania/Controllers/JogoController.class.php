<?php
	require_once "Models/Conexao.class.php";
	require_once "Models/JogoDAO.class.php";
	require_once "Models/Jogo.class.php";
	
	// adicionando o require dos TIPOS para conseguir exibir todos eles no SELECT do form_evento
	require_once "Models/ClassificacaoDAO.class.php";
	require_once "Models/Classificacao.class.php";

	class JogoController
	{
		public function listar()
		{
			$classificacaoDAO = new ClassificacaoDAO();
			$tipos = $classificacaoDAO -> buscar_classificacoes();

			
			$jogoDAO = new JogoDAO();
			$retorno = $jogoDAO -> buscar_todos();

			require_once "Views/listar_jogos.php";
		}


		public function inserir()
		{
			$msg = ["", "", "", "", ""];
			$erro = false;

			if($_POST)
			{
				if(empty($_POST["nome_jogo"]))
				{
					$msg[0] = "Informe o nome do jogo";
					$erro = true;
				}


                if(empty($_POST["nome_personagem_jogo"]))
				{
					$msg[1] = "Informe o nome do personagem do jogo";
					$erro = true;
				}


				if(empty($_POST["data_lancamento_jogo"]))
				{
					$msg[2] = "Informe a data de lançamento do jogo";
					$erro = true;
				}


				if(empty($_POST["duracao_jogo"]))
				{
					$msg[3] = "Digite a duração do jogo, em minutos";
					$erro = true;
				}


				if(empty($_POST["classificacao"]))
				{
					$msg[4] = "Escolha a classificação do jogo";
					$erro = true;
				}

			
				if (!$erro)
				{
					
					$jogo = new Jogo
					(
						0, 
						$_POST["classificacao"],
						$_POST["nome_jogo"],
						$_POST["nome_personagem_jogo"],
						$_POST["data_lancamento_jogo"],
						$_POST["duracao_jogo"]
					);
						
					$jogoDAO = new JogoDAO();
					$retorno = $jogoDAO -> inserir($jogo);


					header('location: index.php?controle=JogoController&metodo=listar');
				}
			}

			$classificacaoDAO = new ClassificacaoDAO();
			$tipos = $classificacaoDAO -> buscar_classificacoes();

			require_once "Views/form_jogo.php";
		}


		public function alterar()
		{
			$msg = array("", "", "", "", "");
			
			if($_POST)
			{
				//verificações
				$erro = false;
				if(empty($_POST["nome_jogo"]))
				{
					$msg[0] = "Informe o nome do jogo";
					$erro = true;
				}


                if(empty($_POST["nome_personagem_jogo"]))
				{
					$msg[1] = "Informe o nome do personagem do jogo";
					$erro = true;
				}


				if(empty($_POST["data_lancamento_jogo"]))
				{
					$msg[2] = "Informe a data de lançamento do jogo";
					$erro = true;
				}


				if(empty($_POST["duracao_jogo"]))
				{
					$msg[3] = "Digite a duração do jogo, em minutos";
					$erro = true;
				}


				if(empty($_POST["classificacao"]))
				{
					$msg[4] = "Escolha a classificação do jogo";
					$erro = true;
				}
				
				if(!$erro)
				{
					//criar um objeto receita
					$jogo = new Jogo($_POST["id_jogo"], $_POST["classificacao"], $_POST["nome_jogo"], $_POST["nome_personagem_jogo"], $_POST["data_lancamento_jogo"], $_POST["duracao_jogo"]);
					$jogoDAO = new JogoDAO();
					$jogoDAO->alterar_jogo($jogo);
					header("location: index.php?controle=JogoController&metodo=listar");
					die();
				}
			}
			//mostrar a visão pegar os dados de jogos que será alterada
			//buscar o JOGO
			
			if(isset($_GET["id_jogo"]))
			{
				
				$jogo = new Jogo($_GET["id_jogo"]);
				$jogoDAO = new JogoDAO();
				$jogos = $jogoDAO->buscar_um($jogo);
			}
			//buscar as classificação cadastradas 
			$classificacaoDAO = new ClassificacaoDAO();
			$tipos = $classificacaoDAO -> buscar_classificacoes();
			//mostrar a view
			require_once "Views/edit_jogo.php";
			
		}


		public function excluir()
		{
			if(isset($_GET["id_jogo"]))
			{	
				$jogo = new Jogo($_GET["id_jogo"]);
				$jogoDAO = new JogoDAO();
				$jogoDAO->excluir_jogo($jogo);
				header("location: index.php?controle=JogoController&metodo=listar");
				die();
			}
		}
	}
?>