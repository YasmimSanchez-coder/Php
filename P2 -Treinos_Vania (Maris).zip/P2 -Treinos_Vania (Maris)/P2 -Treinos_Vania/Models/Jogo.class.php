<?php
	class Jogo 
	{
		public function __construct
		(
			private int $id_jogo = 0, 
			private $id_classificacao = null,
			private string $nome_jogo = "",
            private string $nome_personagem_jogo = "",
			private string $data_lancamento_jogo = "",
			private string $duracao_jogo = ""
		){}

		
		public function getId_Jogo()
		{
			return $this -> id_jogo;
		}


		public function getId_Classificacao()
		{
			return $this -> id_classificacao;
		}


		public function getNome_Jogo()
		{
			return $this -> nome_jogo;
		}


        public function getNome_Personagens_Jogo()
		{
			return $this -> nome_personagem_jogo;
		}


		public function getData()
		{
			return $this -> data_lancamento_jogo;
		}
        

		public function getDuracao_Jogo()
		{
			return $this -> duracao_jogo;
		}
		
	}
?>