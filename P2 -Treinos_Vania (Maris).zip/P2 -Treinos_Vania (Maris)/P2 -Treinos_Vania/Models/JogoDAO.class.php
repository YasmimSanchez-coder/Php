<?php
	class JogoDAO extends Conexao
	{
		public function __construct()
		{
			parent:: __construct();
		}
		
		
		public function inserir($jogo)
		{
			$sql = "INSERT INTO jogos(id_classificacao, nome_jogo, nome_personagem_jogo, data_lancamento_jogo, duracao_jogo) VALUES(?, ?, ?, ?, ?)";
			try
			{
				// não esqueça de trocar os números dos bindValue e o nome do GET!
				$stm = $this -> db -> prepare($sql);
				$stm -> bindValue(1, $jogo -> getId_Classificacao());
				$stm -> bindValue(2, $jogo -> getNome_Jogo());
				$stm -> bindValue(3, $jogo -> getNome_Personagens_Jogo());
				$stm -> bindValue(4, $jogo -> getData());
				$stm -> bindValue(5, $jogo -> getDuracao_Jogo());
				$stm -> execute();

				$this -> db = null;
				return "Jogo inserido com sucesso";
			}
			catch(PDOException $e)
			{
				$this -> db = null;
				return "Problema ao inserir jogo";
			}
		}


		public function buscar_um($jogo)
		{
			$sql = "SELECT * FROM jogos WHERE id_jogo = ?";
			try
			{
				$stm = $this->db->prepare($sql);
				$stm->bindValue(1, $jogo->getId_Jogo());
				$stm->execute();
				$this->db = null;
				return $stm->fetchAll(PDO::FETCH_OBJ);
			}
			catch(PDOException $e)
			{
				$this->db = null;
				return "Problema ao buscar um jogo";
			}
		}


		public function buscar_todos()
		{
			// INNER JOIN para juntar Jogos e Classificação para exibi-los juntos
			$sql = "SELECT jogos.*, classificacao.* 
			FROM jogos
			INNER JOIN classificacao ON classificacao.id_classificacao = jogos.id_classificacao";

			try
			{
				$stm = $this -> db -> prepare($sql);
				$stm -> execute();
				$this -> db = null;
				return $stm -> fetchAll(PDO::FETCH_OBJ);
			}
			catch(PDOException $e)
			{
				$this -> db = null;
				return "Problema ao buscar os jogos";
			}
		}	


		public function excluir_jogo($jogo)
		{
			$sql = "DELETE FROM jogos WHERE id_jogo = ?";
			try
			{
			//preparar frase
			$stm = $this->db->prepare($sql);
			//substituir o ponto de interrogação
			
			$stm->bindValue(1, $jogo->getId_Jogo());
			//executar a frase sql
			$stm->execute();
			//fechar a conexão
			$this->db = null;
			return "Jogo excluido com sucesso";
			}
			catch(PDOException $e)
			{
				$this->db = null;
				return "Problema ao excluir jogo";
			}
			
		}


		public function alterar_jogo($jogo)
		{
			$sql = "UPDATE jogos SET id_classificacao = ?, nome_jogo = ?, nome_personagem_jogo = ?,  data_lancamento_jogo = ?, duracao_jogo = ? WHERE id_jogo= ?";
			try
			{
			//preparar frase
			$stm = $this->db->prepare($sql);
			//substituir o ponto de interrogação
			$stm->bindValue(1, $jogo->getId_Classificacao());
			$stm->bindValue(2, $jogo->getNome_Jogo());
			$stm->bindValue(3, $jogo->getNome_Personagens_Jogo());
			$stm->bindValue(4, $jogo->getData());
			$stm->bindValue(5, $jogo->getDuracao_Jogo());
			$stm->bindValue(6, $jogo->getId_Jogo());
			//executar a frase sql
			$stm->execute();
			//fechar a conexão
			$this->db = null;
			return "Jogo alterado com sucesso";
			}
			catch(PDOException $e)
			{
				$this->db = null;
				return "Problema ao alterar jogo";
			}
			
		}
	}
?>