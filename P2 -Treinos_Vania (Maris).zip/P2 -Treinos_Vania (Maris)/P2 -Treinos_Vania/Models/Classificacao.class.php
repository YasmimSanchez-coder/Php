<?php
	class Classificacao 
	{
		public function __construct(
			private int $id_classificacao = 0,
			private string $descricao = ""
		){}

		public function getId_Classificacao()
		{
			return $this -> id_classificacao;
		}

        public function getDescricao()
		{
			return $this -> descricao;
		}
		
	} //fim da classe tipo
?>