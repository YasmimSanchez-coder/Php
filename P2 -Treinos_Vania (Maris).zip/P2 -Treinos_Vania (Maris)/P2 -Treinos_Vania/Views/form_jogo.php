<?php
	require_once "cabecalho.php";
?>
	<div class="content">
	  <div class="container">
		<h1>JOGOS</h1>
		<form class="form-control" action="index.php?controle=JogoController&metodo=inserir" method="POST" enctype="multipart/form-data"><br>

			<!-- coletando NOME DO JOGO no form -->
			<div class="mb-3">
				<label for="nome_jogo" class="form-label">Nome do Jogo: </label>
				<input type="text"  id="nome_jogo" name="nome_jogo" value="<?php echo isset($_POST['nome_jogo'])?$_POST['nome_jogo']:''?>">
				<div style="color:red"><?php echo $msg[0] != ""?$msg[0]:'';?></div>
			</div>


            <!-- coletando NOME DO PERSONAGEM DO JOGO no form -->
			<div class="mb-3">
				<label for="nome_personagem_jogo" class="form-label">Nome de personagem do Jogo: </label>
				<input type="text"  id="nome_personagem_jogo" name="nome_personagem_jogo" value="<?php echo isset($_POST['nome_personagem_jogo'])?$_POST['nome_personagem_jogo']:''?>">
				<div style="color:red"><?php echo $msg[1] != ""?$msg[1]:'';?></div>
			</div>


			<!-- coletando DATA DE LANÇAMENTO no form -->
			<div class="mb-3">
				<label for="data_lancamento_jogo" class="form-label">Data de lançamento do Jogo: </label>
				<input type="date"  id="data_lancamento_jogo" name="data_lancamento_jogo" value="<?php echo isset($_POST['data_lancamento_jogo'])?$_POST['data_lancamento_jogo']:''?>">
				<div style="color:red"><?php echo $msg[2] != ""?$msg[2]:'';?></div>
			</div>	
	
			<!-- coletando DURAÇÃO DO JOGO no form -->
			<div class="mb-3">
				<label for="duracao_jogo" class="form-label">Duração do Jogo (em minutos): </label>
				<input type="number"  id="duracao_jogo" name="duracao_jogo" value="<?php echo isset($_POST['duracao_jogo'])?$_POST['duracao_jogo']:''?>">
				<div style="color:red"><?php echo $msg[3] != ""?$msg[3]:'';?></div>
			</div>


			<!-- coletando CLASSIFICAÇÃO DO JOGO no form, é um foreach e um select, pois são opções de outra tabela, separada da de eventos (tabela tipos no banco de dados) -->
			<div class="mb-3">
				<label for="classificacao" class="form-label">Tipo:</label>
				<select name="classificacao" id="classificacao">
					<option value="0">Escolha um tipo</option>
				<?php
				foreach($tipos as $dados)
				{
					if(isset($_POST["classificacao"]) && $_POST["classificacao"] == $dados -> id_classificacao)
					{
						echo "<option value='{$dados -> id_classificacao}' selected>{$dados -> descricao}</option>";
					}
					else
					{
						echo "<option value='{$dados -> id_classificacao}'>{$dados -> descricao}</option>";
					}
				}	
					?>
				</select>
				<div style="color:red"><?php echo $msg[4] != ""?$msg[4]:'';?></div>
			</div>
		
			<input class="btn btn-primary" type="submit" value="Enviar">
		</form>
	  </div>
	</div>
</html>