<?php
	require_once "cabecalho.php";

	if(!isset($_SESSION))
	{	
		session_start();
	}

?>

<div class="content">
	<div class="container">
		<br><br><h1>LISTAS DE JOGOS:</h1><br><br>
		<table class="table table-striped">
			<tr>
                <th>Nome</th>
                <th>Nome de personagem</th>
                <th>Data de lançamento</th>
                <th>Duração do jogo</th>
                <th>Id de Classificação</th>
                <th>Categoria do jogo</th>
			</tr>
			<?php	
				foreach($retorno as $dados)
				{
					
					echo "<tr>
							<td>{$dados -> nome_jogo}</td>
							<td>{$dados -> nome_personagem_jogo}</td>
							<td>{$dados -> data_lancamento_jogo}</td>
							<td>{$dados -> duracao_jogo}</td>
							<td>{$dados -> id_classificacao}</td>
							<td>{$dados -> descricao}</td>
						 ";
					
						 if(isset($_SESSION["tipo"]) && $_SESSION["tipo"] === "administrador")	
						 {
							echo "<td><a class='btn btn-success' href='index.php?controle=JogoController&metodo=alterar&id_jogo= {$dados -> id_jogo}'>Alterar</a></td>
							<td><a class='btn btn-danger' href='index.php?controle=JogoController&metodo=excluir&id_jogo= {$dados -> id_jogo}'>Excluir</a></td>";
						} 
						echo "</tr>";
					
				}
				
			?>
		</table>

		<br><br><h1>LISTAS DE CLASSIFICAÇÃO:</h1><br><br>
		<table class="table table-striped">
			<tr>
				<th>Id de Classificação</th>
				<th>Categoria</th>
			</tr>
			<?php	
				foreach($tipos as $dados)
				{
					
					echo "<tr>
							<td>{$dados -> id_classificacao}</td>
							<td>{$dados -> descricao}</td>
						 </tr>";  
				}
			?>
		</table>

		<br><br>

		<?php
		if (isset($_SESSION["tipo"]) && $_SESSION["tipo"] === "administrador")
		{
			echo "<a class='btn btn-success' href='index.php?controle=JogoController&metodo=inserir'>Inserir novo Jogo</a>";
		}
		?>

		<br>

	</div>
</div>
</body>
</html>