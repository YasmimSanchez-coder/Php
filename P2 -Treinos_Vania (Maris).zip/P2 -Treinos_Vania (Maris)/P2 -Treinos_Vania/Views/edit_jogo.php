<?php
	require_once "cabecalho.php";
?>

    <div class="content">
        <div class="container">
            <h1>Jogos </h1>
            <form class="form-control" action="#" method="POST">
                <input type = "hidden" name="id_jogo" value = "<?php echo $jogos[0]->id_jogo?>">

                <div>
                    <label for="nome_jogo">Nome do jogo: </label>
                    <input type="text"  id="nome_jogo" name="nome_jogo" value="<?php echo isset($_POST['nome_jogo'])?$_POST['nome_jogo']:$jogos[0]->nome_jogo?>">
                    <div style="color:red"><?php echo $msg[0] != ""?$msg[0]:'';?></div>
                </div>

                <br><br>

                <div>
                    <label for="nome_personagem_jogo">Nome do personagens jogo: </label>
                    <input type="text"  id="nome_personagem_jogo" name="nome_personagem_jogo" value="<?php echo isset($_POST['nome_personagem_jogo'])?$_POST['nome_personagem_jogo']:$jogos[0]->nome_personagem_jogo?>">
                    <div style="color:red"><?php echo $msg[1] != ""?$msg[1]:'';?></div>
                </div>

                <br><br>

                <div>
                    <label for="data_lancamento_jogo">Data de Lançamento: </label><br>
                    <textarea type="date" name="data_lancamento_jogo" id="data_lancamento_jogo"><?php echo isset($_POST['data_lancamento_jogo'])?$_POST['data_lancamento_jogo']:$jogos[0]->data_lancamento_jogo?></textarea>
                    <div style="color:red"><?php echo $msg[2] != ""?$msg[2]:'';?></div>
                </div>

                <br><br>

                <div>
                    <label for="duracao_jogo">Duração do Jogo (em minutos): </label><br>
                    <textarea type="number" name="duracao_jogo" id="duracao_jogo"><?php echo isset($_POST['duracao_jogo'])?$_POST['duracao_jogo']:$jogos[0]->duracao_jogo?></textarea>
                    <div style="color:red"><?php echo $msg[3] != ""?$msg[3]:'';?></div>
                </div>

                <br><br>

                <div>
                    <label for="classificacao" class="form-label">Tipo: </label>
                    <select name="classificacao" id="classificacao">
                        
                    <?php
                        foreach($tipos as $dado)
                        {
                            if(isset($_POST["classificacao"]) && $_POST["classificacao"] == $dado -> id_classificacao)
                            {
                                echo "<option value='{$dado -> id_classificacao}' selected>{$dado -> descricao}</option>";
                            }
                            else if($jogos[0] -> id_classificacao == $dado -> id_classificacao)
                            {
                                echo "<option value='{$dado -> id_classificacao}' selected>{$dado -> descricao}</option>";
                            }
                            else
                            {
                                echo "<option value='{$dado -> id_classificacao}'>{$dado -> descricao}</option>";
                            }
                        }//fim do foreach
                            
                    ?>
                    </select>
                    <div style="color:red"><?php echo $msg[4] != ""?$msg[4]:'';?></div>
                </div>
                
                <br><br>

                <input type="submit" value="Alterar">
            </form>
	  </div>
	</div>
</body>
</html>