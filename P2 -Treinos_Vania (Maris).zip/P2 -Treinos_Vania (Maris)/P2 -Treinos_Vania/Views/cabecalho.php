<?php
	if(!isset($_SESSION))
	{	
		session_start();
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>JOGOS</title>
		<meta charset="UTF-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
	</head>

	<body>
		<nav class="navbar navbar-expand-lg bg-body-tertiary">
		<div class="container-fluid">
		<a class="navbar-brand" href="index.php?controle=InicioController&metodo=inicio">Jogos</a>	
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav me-auto mb-2 mb-lg-0">
			<li class="nav-item">
				<a class="nav-link active" aria-current="page" href="index.php?controle=JogoController&metodo=listar">Listar Jogos</a>
			</li>

			<?php
				if (isset($_SESSION["tipo"]) && $_SESSION["tipo"] === "administrador")
				{
				echo " <li>
						<a class='nav-link active' aria-current='page' href='index.php?controle=JogoController&metodo=inserir'>Inserir Novos Jogos</a>
						</li>";
				}
			?>

			<?php
				if (isset($_SESSION["nome"]))
				{
					echo "<li>
							<a class='nav-link active' aria-current='page' href='index.php?controle=UsuarioController&metodo=logout'>Sair</a>
						</li>";
				}
				else{
					echo "<li>
				<a class='nav-link active' aria-current='page' href='index.php?controle=UsuarioController&metodo=login'>Entrar</a>
				</li>
				<li>
					<a class='nav-link active' aria-current'page' href='index.php?controle=UsuarioController&metodo=inserir'>Cadastrar</a>
				</li>";
				}
			?>
		</ul>
		</div>
	</div>
	</nav>