<?php
    if ($_GET)
    {
        // TODA VEZ QUE O USUÁRIO CLICAR EM UM LINK
        $controle = $_GET["controle"];
        $metodo = $_GET["metodo"];

        require_once "Controllers/{$controle}.class.php";

        $obj = new $controle();
        $obj -> $metodo();
    }
    else
    {
        // TODA VEZ QUE ENTRAR NO PROJETO
        require_once "Controllers/InicioController.class.php";

        // CRIAR UM OBJETO DA CLASSE INICIOCONTROLLER
        $obj = new InicioController();
        $obj -> inicio();
    }
?>